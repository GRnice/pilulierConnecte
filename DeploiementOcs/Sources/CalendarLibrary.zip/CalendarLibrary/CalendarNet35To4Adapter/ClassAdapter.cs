﻿using CalendarLibrary;
using System;
using System.Runtime.InteropServices;

namespace CalendarNet35To4Adapter
{
    [ComVisible(true)]
    [Guid("A6574755-925A-4E41-A01B-B6A0EEF72DF7")]
    public class ClassAdapter : IMyClassAdapter
    {
        private Calendar  _calendar = new Calendar();

        public void connexion()
        {
            Console.WriteLine("CLR version from DLL: {0}", Environment.Version);
            _calendar.connexion();
            Console.ReadLine();
        }

        public void ajouterSimpleEvent(String mail, String summary, DateTime dateDebut, DateTime dateFin, String location = "")
        {
            Console.WriteLine("COM : ajouterSimpleEvent");
            _calendar.ajouterSimpleEvent(mail, summary, dateDebut, dateFin, location);
        }
    }
}
