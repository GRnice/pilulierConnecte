﻿using System;
using System.Collections.Generic;
using Google.Apis.Calendar.v3;
using Google.Apis.Calendar.v3.Data;
using Google.Apis.Services;
using System.IO;
using Google.Apis.Auth.OAuth2;
using System.Threading;
using Google.Apis.Util.Store;

namespace CalendarLibrary
{
    public class Calendar
    {
        // If modifying these scopes, delete your previously saved credentials
        // at ~/.credentials/calendar-dotnet-quickstart.json
        static string[] Scopes = { CalendarService.Scope.Calendar };
        static string ApplicationName = "Pillulier Connecte - Google Calendar";
        CalendarService service;


        public void connexion()
        {
            UserCredential credential;

            string credPath = System.Environment.GetFolderPath( System.Environment.SpecialFolder.Personal);
            credPath = Path.Combine(credPath, ".credentials/calendar-dotnet-quickstart.json");

            credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                new ClientSecrets
                {
                    ClientId = "838690812265-gr7h7q6u9jh9kjnnvdf4h4a05tk1unr6.apps.googleusercontent.com",
                    ClientSecret = "WZ1Ll5w9kr1ctDKtBIytx0Om"
                },
                Scopes,
                "user",
                CancellationToken.None,
                new FileDataStore(credPath, true)).Result;



            /*  using (var stream =
                  new FileStream("client_secret.json", FileMode.Open, FileAccess.Read))
              {
                  string credPath = System.Environment.GetFolderPath(
                      System.Environment.SpecialFolder.Personal);
                  credPath = Path.Combine(credPath, ".credentials/calendar-dotnet-quickstart.json");

                  credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                      GoogleClientSecrets.Load(stream).Secrets,
                      Scopes,
                      "user",
                      CancellationToken.None,
                      new FileDataStore(credPath, true)).Result;
                  Console.WriteLine("Credential file saved to: " + credPath);
              }*/

            // Create Google Calendar API service.
            service = new CalendarService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });
        }

        public void ajouterSimpleEvent(String mail, String summary, DateTime dateDebut, DateTime dateFin, String location = "")
        {
            //Ajout event
            Event myEvent = new Event
            {
                Summary = summary,
                Location = "",
                Start = new EventDateTime()
                {
                    DateTime = dateDebut,
                    TimeZone = "Europe/Paris"
                },
                End = new EventDateTime()
                {
                    DateTime = dateFin,
                    TimeZone = "Europe/Paris"
                },
                Attendees = new List<EventAttendee>()
                {
                    new EventAttendee() { Email = mail }
                }
            };
            try
            {
                Event recurringEvent = service.Events.Insert(myEvent, "primary").Execute();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
        public void ajouterRecurrentEvent(String mail, String summary, DateTime dateDebut, DateTime dateFin, String[] recurrence, String location)
        {
            // Define parameters of request.
          /*  EventsResource.ListRequest request = service.Events.List("primary");
            request.TimeMin = DateTime.Now;
            request.ShowDeleted = false;
            request.SingleEvents = true;
            request.MaxResults = 10;
            request.OrderBy = EventsResource.ListRequest.OrderByEnum.StartTime;

            //Ajout event

            //recurrence :   "RRULE:FREQ=WEEKLY;BYDAY=MO"
            Event myEvent = new Event
            {
                Summary = summary,
                Location = "",
                Start = new EventDateTime()
                {
                    DateTime = dateDebut,
                    TimeZone = "Europe/Paris"
                },
                End = new EventDateTime()
                {
                    DateTime = dateFin,
                    TimeZone = "Europe/Paris"
                },
                Recurrence = recurrence,
                Attendees = new List<EventAttendee>()
                {
                    new EventAttendee() { Email = mail }
                }
            };
            try
            {
                Event recurringEvent = service.Events.Insert(myEvent, "primary").Execute();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }*/
        }
    }
}
