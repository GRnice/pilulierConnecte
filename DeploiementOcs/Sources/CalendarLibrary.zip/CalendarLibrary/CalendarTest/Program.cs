﻿using CalendarLibrary;
using System;

namespace CalendarTest
{
    class Program
    {
        static void Main(string[] args)
        {
            /*    Calendar c = new Calendar();
                c.connexion();
                c.ajouterSimpleEvent("clesibii@gmail.com", "Prise de médicament", new DateTime(2017, 1, 30, 17, 30, 0), new DateTime(2017, 1, 30, 18, 0, 0));*/
        }

    }
}
