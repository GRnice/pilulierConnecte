﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CalendarNet35To4Adapter;

namespace Calendar35
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("CLR version from EXE: {0}", Environment.Version);

            Type myClassAdapterType = Type.GetTypeFromCLSID(new Guid("A6574755-925A-4E41-A01B-B6A0EEF72DF7"));// .GetTypeFromProgID("c6df36dc -566c-4eed-9892-ad631661d04e");
             Console.WriteLine(myClassAdapterType.FullName);
            object myClassAdapterInstance = Activator.CreateInstance(myClassAdapterType);
            IMyClassAdapter myClassAdapter = (IMyClassAdapter)myClassAdapterInstance;
            myClassAdapter.connexion();
            myClassAdapter.ajouterSimpleEvent("clesib@hotmail.fr", "mon incroyable résumé", new DateTime(2017, 1, 24, 13, 30, 0), new DateTime(2017, 1, 24, 15, 30, 0));
        }
    }
}
