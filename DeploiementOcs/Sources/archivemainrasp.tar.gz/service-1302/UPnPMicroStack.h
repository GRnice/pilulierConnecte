/*   
Copyright 2006 - 2011 Intel Corporation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#ifndef __UPnPMicrostack__
#define __UPnPMicrostack__


#include "ILibAsyncSocket.h"

/*! \file UPnPMicroStack.h 
	\brief MicroStack APIs for Device Implementation
*/

/*! \defgroup MicroStack MicroStack Module
	\{
*/

struct UPnPDataObject;
struct packetheader;

typedef void* UPnPMicroStackToken;
typedef void* UPnPSessionToken;



/* Complex Type Parsers */


/* Complex Type Serializers */



/* UPnP Stack Management */
UPnPMicroStackToken UPnPCreateMicroStack(void *Chain, const char* FriendlyName, const char* UDN, const char* SerialNumber, const int NotifyCycleSeconds, const unsigned short PortNum);


void UPnPIPAddressListChanged(UPnPMicroStackToken MicroStackToken);
int UPnPGetLocalPortNumber(UPnPSessionToken token);
void* UPnPGetWebServerToken(const UPnPMicroStackToken MicroStackToken);
void UPnPSetTag(const UPnPMicroStackToken token, void *UserToken);
void *UPnPGetTag(const UPnPMicroStackToken token);
UPnPMicroStackToken UPnPGetMicroStackTokenFromSessionToken(const UPnPSessionToken token);

typedef void(*UPnP_ActionHandler_ImportedService_turn) (void* upnptoken);
/* UPnP Set Function Pointers Methods */
extern void (*UPnPFP_PresentationPage) (void* upnptoken,struct packetheader *packet);
extern UPnP_ActionHandler_ImportedService_turn UPnPFP_ImportedService_turn;


void UPnPSetDisconnectFlag(UPnPSessionToken token,void *flag);

/* Invocation Response Methods */
void UPnPResponse_Error(const UPnPSessionToken UPnPToken, const int ErrorCode, const char* ErrorMsg);
void UPnPResponseGeneric(const UPnPSessionToken UPnPToken,const char* ServiceURI,const char* MethodName,const char* Params);
void UPnPResponse_ImportedService_turn(const UPnPSessionToken UPnPToken);

/* State Variable Eventing Methods */
void UPnPSetState_ImportedService_unTourComplet(UPnPMicroStackToken microstack,int val);






/*! \} */
#endif
