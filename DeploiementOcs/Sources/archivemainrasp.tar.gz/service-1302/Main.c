/*   
Copyright 2006 - 2011 Intel Corporation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#if defined(WIN32)
	#ifndef MICROSTACK_NO_STDAFX
		#include "stdafx.h"
	#endif
	#define _CRTDBG_MAP_ALLOC
	#include <TCHAR.h>
#endif

#if defined(WINSOCK2)
	#include <winsock2.h>
	#include <ws2tcpip.h>
#elif defined(WINSOCK1)
	#include <winsock.h>
	#include <wininet.h>
#endif
#include "ILibParsers.h"

#include "UPnPMicroStack.h"
#include "ILibWebServer.h"
#include "ILibAsyncSocket.h"

#if defined(WIN32)
	#include <crtdbg.h>
#endif

#include <stdio.h>
#include <unistd.h>
#include <wiringPi.h>

void *MicroStackChain;

void *UPnPmicroStack;

int WaitForExit = 0;
void *ILib_Monitor;
int ILib_IPAddressLength;
int *ILib_IPAddressList;
FILE* stream;

void UPnPImportedService_turn(UPnPSessionToken upnptoken)
{
	printf("Invoke: UPnPImportedService_turn();\r\n");
	
	/* If you intend to make the response later, you MUST reference count upnptoken with calls to ILibWebServer_AddRef() */
	/* and ILibWebServer_Release() */
	
	/* TODO: Place Action Code Here... */
	
	/* UPnPResponse_Error(upnptoken, 404, "Method Not Implemented"); */
        char start[] = "1=140 \n";
        char back[] = "1=165 \n";
        char stop[] = "1=0 \n";
        printf("Turn \n");

        printf("YOP\n");
        printf("%d",digitalRead(24));

        while (digitalRead(24) != 1) // tant que il n'y a pas contact
        {

                stream = fopen("/dev/servoblaster","w");
                fprintf(stream,"%s",start);
                fclose(stream);

                usleep(900);
                stream = fopen("/dev/servoblaster","w");
                fprintf(stream,"%s",stop);
                fclose(stream);
                usleep(5000);



        }
        sleep(2); // on laisse du temps au moteur de s'arreter
        if (digitalRead(24) == 1) // si il s'est arrete sur l'interrupteur
        {
                // on recule de quelques degres.
                stream = fopen("/dev/servoblaster","w");
                fprintf(stream,"%s",back);
                fclose(stream);
                usleep(50000);
                printf("stopBack\n");
                stream = fopen("/dev/servoblaster","w");
                fprintf(stream,"%s",stop);
                fclose(stream);
        }

//      usleep(100*1000);
        printf("END\n");

	

	UPnPResponse_ImportedService_turn(upnptoken);
}



void ILib_IPAddressMonitor(void *data)
{
	int length;
	int *list;
	
	UNREFERENCED_PARAMETER( data );

	length = ILibGetLocalIPAddressList(&list);
	if (length != ILib_IPAddressLength || memcmp((void*)list, (void*)ILib_IPAddressList, sizeof(int)*length) != 0)
	{

UPnPIPAddressListChanged(UPnPmicroStack);
		free(ILib_IPAddressList);
		ILib_IPAddressList = list;
		ILib_IPAddressLength = length;
	}
	else
	{
		free(list);
	}
	ILibLifeTime_Add(ILib_Monitor, NULL, 4, (void*)&ILib_IPAddressMonitor, NULL);
}

void ILib_LinuxQuit(void *data)
{
	UNREFERENCED_PARAMETER( data );

	if(MicroStackChain != NULL)
	{
		ILibStopChain(MicroStackChain);
		MicroStackChain = NULL;
	}
}
void BreakSink(int s)
{
	if(WaitForExit == 0)
	{
		ILibLifeTime_Add(ILib_Monitor, NULL, 0, (void*)&ILib_LinuxQuit, NULL);
		WaitForExit = 1;
	}
}

int main(void) 
{
	struct sigaction setup_action;
    sigset_t block_mask;

    wiringPiSetupGpio();
    pinMode(24,INPUT);
    pullUpDnControl(24,PUD_DOWN);
     
	MicroStackChain = ILibCreateChain();


	// TODO: Each device must have a unique device identifier (UDN)
	UPnPmicroStack = UPnPCreateMicroStack(MicroStackChain, "PilulierFinal1302", "8c513df3-da8a-4a3f-aa65-ae03c0794b89", "0000001", 1800, 45555);


	UPnPFP_ImportedService_turn = (UPnP_ActionHandler_ImportedService_turn)&UPnPImportedService_turn;
	
	

// All evented state variables MUST be initialized before UPnPStart is called.
UPnPSetState_ImportedService_unTourComplet(UPnPmicroStack, 1);

	printf("MicroStack 1.0 - PilulierFinal1302 \r\n\r\n");

ILib_Monitor = ILibCreateLifeTime(MicroStackChain);	ILib_IPAddressLength = ILibGetLocalIPAddressList(&ILib_IPAddressList);
	ILibLifeTime_Add(ILib_Monitor, NULL, 4, (void*)&ILib_IPAddressMonitor, NULL);
	sigemptyset(&block_mask);
	// Block other terminal-generated signals while handler runs.
    sigaddset(&block_mask, SIGINT);
    sigaddset(&block_mask, SIGQUIT);
    setup_action.sa_handler = BreakSink;
    setup_action.sa_mask = block_mask;
    setup_action.sa_flags = 0;
    sigaction(SIGINT, &setup_action, NULL);
	WaitForExit = 0;
	ILibStartChain(MicroStackChain);
	free(ILib_IPAddressList);
	return 0;
}

