/*   
Copyright 2006 - 2011 Intel Corporation

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

char const * UPnPXmlLocation = "/upnp.xml";

#if defined(WIN32) || defined(_WIN32_WCE)
#	ifndef MICROSTACK_NO_STDAFX
#		include "stdafx.h"
#	endif
char* UPnPPLATFORM = "WINDOWS";
#elif defined(__SYMBIAN32__)
char* UPnPPLATFORM = "SYMBIAN";
#else
char* UPnPPLATFORM = "POSIX";
#endif

#if defined(WIN32)
#define snprintf sprintf_s
#define _CRTDBG_MAP_ALLOC
#endif

#if defined(WINSOCK2)
#	include <winsock2.h>
#	include <ws2tcpip.h>
#elif defined(WINSOCK1)
#	include <winsock.h>
#	include <wininet.h>
#endif

#include "ILibParsers.h"
#include "UPnPMicroStack.h"
#include "ILibWebServer.h"
#include "ILibWebClient.h"
#include "ILibAsyncSocket.h"
#include "ILibAsyncUDPSocket.h"

#if defined(WIN32) && !defined(_WIN32_WCE)
#include <crtdbg.h>
#endif

#define UPNP_SSDP_TTL 4
#define UPNP_HTTP_MAXSOCKETS 5
#define UPNP_MAX_SSDP_HEADER_SIZE 4096
#define UPNP_PORT 1900
#define UPNP_MCASTv4_GROUP "239.255.255.250"
#define UPNP_MCASTv6_GROUP "FF05:0:0:0:0:0:0:C" // Site local
#define UPNP_MCASTv6_GROUPB "[FF05:0:0:0:0:0:0:C]"
#define UPNP_MCASTv6_LINK_GROUP "FF02:0:0:0:0:0:0:C" // Link local
#define UPNP_MCASTv6_LINK_GROUPB "[FF02:0:0:0:0:0:0:C]"
#define UPnP_MAX_SUBSCRIPTION_TIMEOUT 7200
#define UPnPMIN(a,b) (((a)<(b))?(a):(b))

#define LVL3DEBUG(x)
#define INET_SOCKADDR_LENGTH(x) ((x==AF_INET6?sizeof(struct sockaddr_in6):sizeof(struct sockaddr_in)))

#if defined(WIN32)
#pragma warning( push, 3 ) // warning C4310: cast truncates constant value
#endif
//{{{ObjectDefintions}}}
UPnPMicroStackToken UPnPCreateMicroStack(void *Chain, const char* FriendlyName, const char* UDN, const char* SerialNumber, const int NotifyCycleSeconds, const unsigned short PortNum);
/* UPnP Set Function Pointers Methods */
void (*UPnPFP_PresentationPage) (void* upnptoken,struct packetheader *packet);
/*! \var UPnPFP_ImportedService_turn
\brief Dispatch Pointer for ImportedService >> urn:schemas-upnp-org:service::1 >> turn
*/
UPnP_ActionHandler_ImportedService_turn UPnPFP_ImportedService_turn;


const int UPnPDeviceDescriptionTemplateLengthUX = 841;
const int UPnPDeviceDescriptionTemplateLength = 512;
const char UPnPDeviceDescriptionTemplate[512]={
	0x5A,0x3C,0x3F,0x78,0x6D,0x6C,0x20,0x76,0x65,0x72,0x73,0x69,0x6F,0x6E,0x3D,0x22,0x31,0x2E,0x30,0x22
	,0x20,0x65,0x6E,0x63,0x6F,0x64,0x69,0x6E,0x67,0x3D,0x22,0x75,0x74,0x66,0x2D,0x38,0x22,0x3F,0x3E,0x3C
	,0x72,0x6F,0x6F,0x74,0x20,0x78,0x6D,0x6C,0x6E,0x73,0x3D,0x22,0x75,0x72,0x6E,0x3A,0x73,0x63,0x68,0x65
	,0x6D,0x61,0x73,0x2D,0x75,0x70,0x6E,0x70,0x2D,0x6F,0x72,0x67,0x3A,0x64,0x65,0x76,0x69,0x63,0x65,0x2D
	,0x31,0x2D,0x30,0x22,0x3E,0x3C,0x73,0x70,0x65,0x63,0x56,0xC6,0x14,0x0B,0x3E,0x3C,0x6D,0x61,0x6A,0x6F
	,0x72,0x3E,0x31,0x3C,0x2F,0x46,0x02,0x0A,0x3C,0x6D,0x69,0x6E,0x6F,0x72,0x3E,0x30,0x3C,0x2F,0x46,0x02
	,0x02,0x3C,0x2F,0x8D,0x0B,0x00,0x06,0x12,0x00,0x08,0x02,0x05,0x54,0x79,0x70,0x65,0x3E,0x1B,0x1C,0x0B
	,0x3A,0x53,0x61,0x6D,0x70,0x6C,0x65,0x3A,0x31,0x3C,0x2F,0x4B,0x0C,0x12,0x3C,0x66,0x72,0x69,0x65,0x6E
	,0x64,0x6C,0x79,0x4E,0x61,0x6D,0x65,0x3E,0x25,0x73,0x3C,0x2F,0x4D,0x04,0x1A,0x3C,0x6D,0x61,0x6E,0x75
	,0x66,0x61,0x63,0x74,0x75,0x72,0x65,0x72,0x3E,0x4F,0x70,0x65,0x6E,0x53,0x6F,0x75,0x72,0x63,0x65,0x3C
	,0x2F,0x4D,0x06,0x00,0xCD,0x09,0x21,0x55,0x52,0x4C,0x3E,0x68,0x74,0x74,0x70,0x3A,0x2F,0x2F,0x6F,0x70
	,0x65,0x6E,0x74,0x6F,0x6F,0x6C,0x73,0x2E,0x68,0x6F,0x6D,0x65,0x69,0x70,0x2E,0x6E,0x65,0x74,0x3C,0x2F
	,0x50,0x0B,0x0E,0x3C,0x6D,0x6F,0x64,0x65,0x6C,0x44,0x65,0x73,0x63,0x72,0x69,0x70,0x74,0x44,0x42,0x00
	,0xC6,0x2A,0x07,0x20,0x55,0x50,0x6E,0x50,0x20,0x44,0x85,0x4B,0x15,0x20,0x55,0x73,0x69,0x6E,0x67,0x20
	,0x41,0x75,0x74,0x6F,0x2D,0x47,0x65,0x6E,0x65,0x72,0x61,0x74,0x65,0x64,0x46,0x08,0x07,0x53,0x74,0x61
	,0x63,0x6B,0x3C,0x2F,0x51,0x11,0x00,0xC6,0x15,0x00,0x05,0x36,0x06,0x50,0x46,0x31,0x33,0x3C,0x2F,0x0A
	,0x04,0x00,0xC7,0x06,0x0A,0x75,0x6D,0x62,0x65,0x72,0x3E,0x58,0x31,0x3C,0x2F,0x0C,0x04,0x06,0x3C,0x73
	,0x65,0x72,0x69,0x61,0x88,0x07,0x00,0xC4,0x44,0x00,0x4D,0x04,0x0A,0x3C,0x55,0x44,0x4E,0x3E,0x75,0x75
	,0x69,0x64,0x3A,0x84,0x4B,0x03,0x55,0x44,0x4E,0x45,0x0C,0x00,0x84,0x74,0x04,0x4C,0x69,0x73,0x74,0x49
	,0x03,0x00,0x89,0x05,0x00,0x1A,0x66,0x00,0xC7,0x0D,0x03,0x3A,0x3A,0x31,0xC5,0x18,0x00,0x0A,0x65,0x00
	,0x07,0x14,0x02,0x49,0x64,0x05,0x74,0x00,0x10,0x0C,0x05,0x49,0x64,0x3A,0x3C,0x2F,0xCA,0x08,0x05,0x3C
	,0x53,0x43,0x50,0x44,0x04,0x5D,0x09,0x49,0x6D,0x70,0x6F,0x72,0x74,0x65,0x64,0x53,0x86,0x23,0x0B,0x2F
	,0x73,0x63,0x70,0x64,0x2E,0x78,0x6D,0x6C,0x3C,0x2F,0x88,0x08,0x08,0x3C,0x63,0x6F,0x6E,0x74,0x72,0x6F
	,0x6C,0x94,0x0B,0x00,0xC7,0x06,0x02,0x3C,0x2F,0x0B,0x09,0x09,0x3C,0x65,0x76,0x65,0x6E,0x74,0x53,0x75
	,0x62,0xD4,0x17,0x00,0x05,0x07,0x02,0x3C,0x2F,0xCC,0x08,0x00,0xC9,0x31,0x03,0x3E,0x3C,0x2F,0x0D,0x45
	,0x01,0x2F,0xC8,0xAA,0x01,0x2F,0x44,0xC7,0x01,0x3E,0x00,0x00};
/* ImportedService */
const int UPnPImportedServiceDescriptionLengthUX = 480;
const int UPnPImportedServiceDescriptionLength = 388;
const char UPnPImportedServiceDescription[388] = {
	0x4E,0x48,0x54,0x54,0x50,0x2F,0x31,0x2E,0x31,0x20,0x32,0x30,0x30,0x20,0x20,0x4F,0x4B,0x0D,0x0A,0x43
	,0x4F,0x4E,0x54,0x45,0x4E,0x54,0x2D,0x54,0x59,0x50,0x45,0x3A,0x20,0x20,0x74,0x65,0x78,0x74,0x2F,0x78
	,0x6D,0x6C,0x3B,0x20,0x63,0x68,0x61,0x72,0x73,0x65,0x74,0x3D,0x22,0x75,0x74,0x66,0x2D,0x38,0x22,0x0D
	,0x0A,0x53,0x65,0x72,0x76,0x65,0x72,0x3A,0x20,0x50,0x4F,0x53,0x49,0x58,0x2C,0x20,0x55,0x50,0x6E,0xC4
	,0x12,0x0D,0x30,0x2C,0x20,0x4D,0x69,0x63,0x72,0x6F,0x53,0x74,0x61,0x63,0x6B,0x04,0x04,0x3A,0x2E,0x35
	,0x33,0x32,0x39,0x0D,0x0A,0x43,0x6F,0x6E,0x74,0x65,0x6E,0x74,0x2D,0x4C,0x65,0x6E,0x67,0x74,0x68,0x3A
	,0x20,0x33,0x35,0x31,0x0D,0x0A,0x0D,0x0A,0x3C,0x3F,0x78,0x6D,0x6C,0x20,0x76,0x65,0x72,0x73,0x69,0x6F
	,0x6E,0x3D,0x22,0x31,0x2E,0x30,0x22,0x20,0x65,0x6E,0x63,0x6F,0x64,0x69,0x6E,0x67,0xC8,0x1A,0x37,0x3F
	,0x3E,0x3C,0x73,0x63,0x70,0x64,0x20,0x78,0x6D,0x6C,0x6E,0x73,0x3D,0x22,0x75,0x72,0x6E,0x3A,0x73,0x63
	,0x68,0x65,0x6D,0x61,0x73,0x2D,0x75,0x70,0x6E,0x70,0x2D,0x6F,0x72,0x67,0x3A,0x73,0x65,0x72,0x76,0x69
	,0x63,0x65,0x2D,0x31,0x2D,0x30,0x22,0x3E,0x3C,0x73,0x70,0x65,0x63,0x56,0x06,0x15,0x0B,0x3E,0x3C,0x6D
	,0x61,0x6A,0x6F,0x72,0x3E,0x31,0x3C,0x2F,0x46,0x02,0x0A,0x3C,0x6D,0x69,0x6E,0x6F,0x72,0x3E,0x30,0x3C
	,0x2F,0x46,0x02,0x02,0x3C,0x2F,0x8D,0x0B,0x0A,0x61,0x63,0x74,0x69,0x6F,0x6E,0x4C,0x69,0x73,0x74,0x08
	,0x03,0x0D,0x3E,0x3C,0x6E,0x61,0x6D,0x65,0x3E,0x74,0x75,0x72,0x6E,0x3C,0x2F,0xC5,0x02,0x02,0x3C,0x2F
	,0x88,0x06,0x01,0x2F,0xCC,0x0B,0x00,0x07,0x21,0x0D,0x53,0x74,0x61,0x74,0x65,0x54,0x61,0x62,0x6C,0x65
	,0x3E,0x3C,0x73,0x04,0x03,0x04,0x56,0x61,0x72,0x69,0xC4,0x03,0x11,0x20,0x73,0x65,0x6E,0x64,0x45,0x76
	,0x65,0x6E,0x74,0x73,0x3D,0x22,0x79,0x65,0x73,0x22,0x87,0x16,0x0D,0x75,0x6E,0x54,0x6F,0x75,0x72,0x43
	,0x6F,0x6D,0x70,0x6C,0x65,0x74,0xC8,0x18,0x12,0x64,0x61,0x74,0x61,0x54,0x79,0x70,0x65,0x3E,0x62,0x6F
	,0x6F,0x6C,0x65,0x61,0x6E,0x3C,0x2F,0x89,0x04,0x02,0x3C,0x2F,0xCD,0x15,0x03,0x3E,0x3C,0x2F,0x93,0x1E
	,0x01,0x2F,0xC4,0x4C,0x01,0x3E,0x00,0x00};

#if defined(WIN32)
#pragma warning( pop )
#endif

struct UPnPDataObject;

// It should not be necessary to expose/modify any of these structures. They are used by the internal stack
struct SubscriberInfo
{
	char* SID;		// Subscription ID
	int SIDLength;
	int SEQ;
	
	int Address;
	unsigned short Port;
	char* Path;
	int PathLength;
	int RefCount;
	int Disposing;
	
	struct timeval RenewByTime;
	
	struct SubscriberInfo *Next;
	struct SubscriberInfo *Previous;
};

struct UPnPDataObject
{
	// Absolutely DO NOT put anything above these 3 function pointers
	ILibChain_PreSelect PreSelect;
	ILibChain_PostSelect PostSelect;
	ILibChain_Destroy Destroy;
	
	void *EventClient;
	void *Chain;
	int UpdateFlag;
	
	// Network Poll
	unsigned int NetworkPollTime;
	
	int ForceExit;
	char *UUID;
	char *UDN;
	char *Serial;
	void *User;
	void *User2;
	
	void *WebServerTimer;
	void *HTTPServer;
	char *DeviceDescription;
	int DeviceDescriptionLength;	int InitialNotify;
	char* ImportedService_unTourComplet;
	
	struct sockaddr_in addr;
	int addrlen;
	
	// Current local interfaces
	struct sockaddr_in* AddressListV4;
	int AddressListV4Length;
	struct sockaddr_in6* AddressListV6;
	int AddressListV6Length;
	
	// Multicast Addresses
	struct sockaddr_in MulticastAddrV4;
	struct sockaddr_in6 MulticastAddrV6SL;
	struct sockaddr_in6 MulticastAddrV6LL;
	
	int _NumEmbeddedDevices;
	int WebSocketPortNumber;
	
	void **NOTIFY_RECEIVE_socks;
	void **NOTIFY_SEND_socks;
	void **NOTIFY_RECEIVE_socks6;
	void **NOTIFY_SEND_socks6;
	struct timeval CurrentTime;
	struct timeval NotifyTime;
	
	int SID;
	int NotifyCycleTime;
	sem_t EventLock;
	struct SubscriberInfo *HeadSubscriberPtr_ImportedService;
	int NumberOfSubscribers_ImportedService;
	
};

struct MSEARCH_state
{
	char *ST;
	int STLength;
	void *upnp;
	struct sockaddr_in6 dest_addr;
	struct sockaddr_in6 localIPAddress;
	void *Chain;
	void *SubChain;
};
struct UPnPFragmentNotifyStruct
{
	struct UPnPDataObject *upnp;
	int packetNumber;
};

/* Pre-declarations */
void UPnPFragmentedSendNotify(void *data);
void UPnPSendNotify(const struct UPnPDataObject *upnp);
void UPnPSendByeBye(const struct UPnPDataObject *upnp);
void UPnPMainInvokeSwitch();
void UPnPSendDataXmlEscaped(const void* UPnPToken, const char* Data, const int DataLength, const int Terminate);
void UPnPSendData(const void* UPnPToken, const char* Data, const int DataLength, const int Terminate);
int UPnPPeriodicNotify(struct UPnPDataObject *upnp);
void UPnPSendEvent_Body(void *upnptoken, char *body, int bodylength, struct SubscriberInfo *info);
void UPnPProcessMSEARCH(struct UPnPDataObject *upnp, struct packetheader *packet);
struct in_addr UPnP_inaddr;

/*! \fn UPnPGetWebServerToken(const UPnPMicroStackToken MicroStackToken)
\brief Converts a MicroStackToken to a WebServerToken
\par
\a MicroStackToken is the void* returned from a call to UPnPCreateMicroStack. The returned token, is the server token
not the session token.
\param MicroStackToken MicroStack Token
\returns WebServer Token
*/
void* UPnPGetWebServerToken(const UPnPMicroStackToken MicroStackToken)
{
	return(((struct UPnPDataObject*)MicroStackToken)->HTTPServer);
}
int UPnPBuildSendSsdpResponsePacket(void* module, const struct UPnPDataObject *upnp, struct sockaddr* local, struct sockaddr* target, int EmbeddedDeviceNumber, char* USNex, char* ST, char* NTex)
{
	int len;
	UNREFERENCED_PARAMETER( EmbeddedDeviceNumber );
	
	if (local->sa_family == AF_INET)
	{
		// IPv4 address format
		ILibInet_ntop(local->sa_family, &(((struct sockaddr_in*)local)->sin_addr), ILibScratchPad2, sizeof(ILibScratchPad2));
	}
	else if (local->sa_family == AF_INET6)
	{
		// IPv6 address format
		size_t len2;
		ILibScratchPad2[0] = '[';
		ILibInet_ntop(local->sa_family, &(((struct sockaddr_in6*)local)->sin6_addr), ILibScratchPad2 + 1, sizeof(ILibScratchPad2) - 2);
		len2 = strlen(ILibScratchPad2);
		ILibScratchPad2[len2] = ']';
		ILibScratchPad2[len2 + 1] = 0;
	}
	
	len = snprintf(ILibScratchPad, sizeof(ILibScratchPad), "HTTP/1.1 200 OK\r\nLOCATION: http://%s:%d%s\r\nEXT:\r\nSERVER: %s, UPnP/1.0, MicroStack/1.0.5329\r\nUSN: uuid:%s%s\r\nCACHE-CONTROL: max-age=%d\r\nST: %s%s\r\n\r\n", ILibScratchPad2, upnp->WebSocketPortNumber, UPnPXmlLocation, UPnPPLATFORM, upnp->UDN, USNex, upnp->NotifyCycleTime, ST, NTex);
	return ILibAsyncUDPSocket_SendTo(module, target, ILibScratchPad, len, ILibAsyncSocket_MemoryOwnership_USER);
}

int UPnPBuildSendSsdpNotifyPacket(void* module, const struct UPnPDataObject *upnp, struct sockaddr* local, int EmbeddedDeviceNumber, char* USNex, char* NT, char* NTex)
{
	int len;
	struct sockaddr* multicast = NULL;
	char* mcaststr = NULL;
	UNREFERENCED_PARAMETER( EmbeddedDeviceNumber );
	
	if (local->sa_family == AF_INET)
	{
		// IPv4 address format
		ILibInet_ntop(local->sa_family, &(((struct sockaddr_in*)local)->sin_addr), ILibScratchPad2, sizeof(ILibScratchPad2));
		multicast = (struct sockaddr*)&(upnp->MulticastAddrV4);
		mcaststr = UPNP_MCASTv4_GROUP;
	}
	else if (local->sa_family == AF_INET6)
	{
		// IPv6 address format
		size_t len;
		ILibScratchPad2[0] = '[';
		ILibInet_ntop(local->sa_family, &(((struct sockaddr_in6*)local)->sin6_addr), ILibScratchPad2 + 1, sizeof(ILibScratchPad2) - 2);
		len = strlen(ILibScratchPad2);
		ILibScratchPad2[len] = ']';
		ILibScratchPad2[len + 1] = 0;
		if (ILibAsyncSocket_IsIPv6LinkLocal(local))
		{
			multicast = (struct sockaddr*)&(upnp->MulticastAddrV6LL);
			mcaststr = UPNP_MCASTv6_LINK_GROUPB;
		}
		else
		{
			multicast = (struct sockaddr*)&(upnp->MulticastAddrV6SL);
			mcaststr = UPNP_MCASTv6_GROUPB;
		}
	}
	else return 0;
	
	len = snprintf(ILibScratchPad, sizeof(ILibScratchPad), "NOTIFY * HTTP/1.1\r\nLOCATION: http://%s:%d%s\r\nHOST: %s:1900\r\nSERVER: %s, UPnP/1.0, MicroStack/1.0.5329\r\nNTS: ssdp:alive\r\nUSN: uuid:%s%s\r\nCACHE-CONTROL: max-age=%d\r\nNT: %s%s\r\n\r\n", ILibScratchPad2, upnp->WebSocketPortNumber, UPnPXmlLocation, mcaststr, UPnPPLATFORM, upnp->UDN, USNex, upnp->NotifyCycleTime, NT, NTex);
	return ILibAsyncUDPSocket_SendTo(module, multicast, ILibScratchPad, len, ILibAsyncSocket_MemoryOwnership_USER);
}
void UPnPSetDisconnectFlag(UPnPSessionToken token,void *flag)
{
	((struct ILibWebServer_Session*)token)->Reserved10=flag;
}

/*! \fn UPnPIPAddressListChanged(UPnPMicroStackToken MicroStackToken)
\brief Tell the underlying MicroStack that an IPAddress may have changed
\param MicroStackToken Microstack
*/
void UPnPIPAddressListChanged(UPnPMicroStackToken MicroStackToken)
{
	((struct UPnPDataObject*)MicroStackToken)->UpdateFlag = 1;
	ILibForceUnBlockChain(((struct UPnPDataObject*)MicroStackToken)->Chain);
}

void UPnPSSDPSink(ILibAsyncUDPSocket_SocketModule socketModule, char* buffer, int bufferLength, struct sockaddr_in6 *remoteInterface, void *user, void *user2, int *PAUSE)
{
	struct packetheader *packet;
	UNREFERENCED_PARAMETER( user2 );
	UNREFERENCED_PARAMETER( PAUSE );
	
	packet = ILibParsePacketHeader(buffer, 0, bufferLength);
	if (packet != NULL)
	{
		// Fill in the source and local interface addresses
		memcpy(&(packet->Source), remoteInterface, INET_SOCKADDR_LENGTH(remoteInterface->sin6_family));
		ILibAsyncUDPSocket_GetLocalInterface(socketModule, (struct sockaddr*)&(packet->ReceivingAddress));
		
		if (packet->StatusCode == -1 && memcmp(packet->Directive, "M-SEARCH", 8) == 0 && ((struct sockaddr_in6*)(packet->ReceivingAddress))->sin6_family != 0)
		{
			// Process the search request with our Multicast M-SEARCH Handler
			UPnPProcessMSEARCH(user, packet);
		}
		ILibDestructPacket(packet);
	}
}
//
//	Internal underlying Initialization, that shouldn't be called explicitely
// 
// <param name="state">State object</param>
// <param name="NotifyCycleSeconds">Cycle duration</param>
// <param name="PortNumber">Port Number</param>
void UPnPInit(struct UPnPDataObject *state, void *chain, const int NotifyCycleSeconds, const unsigned short PortNumber)
{
	int i;
	struct sockaddr_in any4;
	struct sockaddr_in6 any6;
	UNREFERENCED_PARAMETER( PortNumber );
	
	// Setup ANY addresses
	memset(&any4, 0, sizeof(struct sockaddr_in));
	any4.sin_family = AF_INET;
	any4.sin_port = htons(UPNP_PORT);
	memset(&any6, 0, sizeof(struct sockaddr_in6));
	any6.sin6_family = AF_INET6;
	any6.sin6_port = htons(UPNP_PORT);
	
	state->Chain = chain;
	
	// Setup notification timer
	state->NotifyCycleTime = NotifyCycleSeconds;
	gettimeofday(&(state->CurrentTime), NULL);
	(state->NotifyTime).tv_sec = (state->CurrentTime).tv_sec  + (state->NotifyCycleTime / 2);
	
	// Fetch the list of local IPv4 interfaces
	state->AddressListV4Length = ILibGetLocalIPv4AddressList(&(state->AddressListV4), 1);
	
	// Setup the IPv4 sockets
	if ((state->NOTIFY_SEND_socks = (void**)malloc(sizeof(void*)*(state->AddressListV4Length))) == NULL) ILIBCRITICALEXIT(254);
	if ((state->NOTIFY_RECEIVE_socks = (void**)malloc(sizeof(void*)*(state->AddressListV4Length))) == NULL) ILIBCRITICALEXIT(254);
	
	// Setup multicast IPv4 address
	memset(&state->MulticastAddrV4, 0, sizeof(struct sockaddr_in));
	state->MulticastAddrV4.sin_family = AF_INET;
	state->MulticastAddrV4.sin_port = htons(UPNP_PORT);
	ILibInet_pton(AF_INET, UPNP_MCASTv4_GROUP, &(state->MulticastAddrV4.sin_addr));
	
	// Test IPv6 support
	if (ILibDetectIPv6Support())
	{
		// Fetch the list of local IPv6 interfaces
		state->AddressListV6Length = ILibGetLocalIPv6List(&(state->AddressListV6));
		
		// Setup the IPv6 sockets
		if ((state->NOTIFY_SEND_socks6 = (void**)malloc(sizeof(void*)*(state->AddressListV6Length))) == NULL) ILIBCRITICALEXIT(254);
		if ((state->NOTIFY_RECEIVE_socks6 = (void**)malloc(sizeof(void*)*(state->AddressListV6Length))) == NULL) ILIBCRITICALEXIT(254);
		
		// Setup multicast IPv6 address (Site Local)
		memset(&state->MulticastAddrV6SL, 0, sizeof(struct sockaddr_in6));
		state->MulticastAddrV6SL.sin6_family = AF_INET6;
		state->MulticastAddrV6SL.sin6_port = htons(UPNP_PORT);
		ILibInet_pton(AF_INET6, UPNP_MCASTv6_GROUP, &(state->MulticastAddrV6SL.sin6_addr));
		
		// Setup multicast IPv6 address (Link Local)
		memset(&state->MulticastAddrV6LL, 0, sizeof(struct sockaddr_in6));
		state->MulticastAddrV6LL.sin6_family = AF_INET6;
		state->MulticastAddrV6LL.sin6_port = htons(UPNP_PORT);
		ILibInet_pton(AF_INET6, UPNP_MCASTv6_LINK_GROUP, &(state->MulticastAddrV6LL.sin6_addr));
	}
	
	// Iterate through all the current IPv4 addresses
	for (i = 0; i < state->AddressListV4Length; ++i)
	{
		(state->AddressListV4[i]).sin_port = 0; // Bind to ANY port for outbound packets
		state->NOTIFY_SEND_socks[i] = ILibAsyncUDPSocket_CreateEx(
		chain,
		UPNP_MAX_SSDP_HEADER_SIZE,
		(struct sockaddr*)&(state->AddressListV4[i]),
		ILibAsyncUDPSocket_Reuse_SHARED,
		NULL,
		NULL,
		state);
		
		ILibAsyncUDPSocket_SetMulticastTTL(state->NOTIFY_SEND_socks[i], UPNP_SSDP_TTL);
		ILibAsyncUDPSocket_SetMulticastLoopback(state->NOTIFY_SEND_socks[i], 1);
		
		(state->AddressListV4[i]).sin_port = htons(UPNP_PORT); // Bind to UPnP port for inbound packets
		state->NOTIFY_RECEIVE_socks[i] = ILibAsyncUDPSocket_CreateEx(
		state->Chain,
		UPNP_MAX_SSDP_HEADER_SIZE,
		(struct sockaddr*)&any4,
		ILibAsyncUDPSocket_Reuse_SHARED,
		&UPnPSSDPSink,
		NULL,
		state);
		
		ILibAsyncUDPSocket_JoinMulticastGroupV4(state->NOTIFY_RECEIVE_socks[i], (struct sockaddr_in*)&(state->MulticastAddrV4), (struct sockaddr*)&(state->AddressListV4[i]));
		ILibAsyncUDPSocket_SetLocalInterface(state->NOTIFY_RECEIVE_socks[i], (struct sockaddr*)&(state->AddressListV4[i]));
		ILibAsyncUDPSocket_SetMulticastLoopback(state->NOTIFY_RECEIVE_socks[i], 1);
	}
	
	if (state->AddressListV6Length > 0)
	{
		// Iterate through all the current IPv6 interfaces
		for (i = 0; i < state->AddressListV6Length; ++i)
		{
			(state->AddressListV6[i]).sin6_port = 0;
			state->NOTIFY_SEND_socks6[i] = ILibAsyncUDPSocket_CreateEx(
			chain,
			UPNP_MAX_SSDP_HEADER_SIZE,
			(struct sockaddr*)&(state->AddressListV6[i]),
			ILibAsyncUDPSocket_Reuse_SHARED,
			NULL,
			NULL,
			state);
			
			ILibAsyncUDPSocket_SetMulticastTTL(state->NOTIFY_SEND_socks6[i], UPNP_SSDP_TTL);
			ILibAsyncUDPSocket_SetMulticastLoopback(state->NOTIFY_SEND_socks6[i], 1);
			
			(state->AddressListV6[i]).sin6_port = htons(UPNP_PORT); // Bind to UPnP port for inbound packets
			state->NOTIFY_RECEIVE_socks6[i] = ILibAsyncUDPSocket_CreateEx(
			state->Chain,
			UPNP_MAX_SSDP_HEADER_SIZE,
			(struct sockaddr*)&any6,
			ILibAsyncUDPSocket_Reuse_SHARED,
			&UPnPSSDPSink,
			NULL,
			state);
			
			if (ILibAsyncSocket_IsIPv6LinkLocal((struct sockaddr*)&(state->AddressListV6[i])))
			{
				ILibAsyncUDPSocket_JoinMulticastGroupV6(state->NOTIFY_RECEIVE_socks6[i], &(state->MulticastAddrV6LL), state->AddressListV6[i].sin6_scope_id);
			}
			else
			{
				ILibAsyncUDPSocket_JoinMulticastGroupV6(state->NOTIFY_RECEIVE_socks6[i], &(state->MulticastAddrV6SL), state->AddressListV6[i].sin6_scope_id);
			}
			ILibAsyncUDPSocket_SetMulticastLoopback(state->NOTIFY_RECEIVE_socks6[i], 1);
			ILibAsyncUDPSocket_SetLocalInterface(state->NOTIFY_RECEIVE_socks6[i], (struct sockaddr*)&(state->AddressListV6[i]));
		}
	}
}

void UPnPPostMX_Destroy(void *object)
{
	struct MSEARCH_state *mss = (struct MSEARCH_state*)object;
	free(mss->ST);
	free(mss);
}
void UPnPOnPostMX_MSEARCH_SendOK(ILibAsyncUDPSocket_SocketModule socketModule, void *user1, void *user2)
{
	struct MSEARCH_state *mss = (struct MSEARCH_state*)user1;
	UNREFERENCED_PARAMETER( socketModule );
	UNREFERENCED_PARAMETER( user2 );
	
	ILibChain_SafeRemove_SubChain(mss->Chain, mss->SubChain);
	free(mss->ST);
	free(mss);
}

void UPnPPostMX_MSEARCH(void *object)
{
	struct MSEARCH_state *mss = (struct MSEARCH_state*)object;
	void *response_socket;
	void *subChain;
	char *ST = mss->ST;
	int STLength = mss->STLength;
	struct UPnPDataObject *upnp = (struct UPnPDataObject*)mss->upnp;
	int rcode = 0;
	
	subChain = ILibCreateChain();
	
	response_socket = ILibAsyncUDPSocket_CreateEx(
	subChain,
	UPNP_MAX_SSDP_HEADER_SIZE,
	(struct sockaddr*)&(mss->localIPAddress),
	ILibAsyncUDPSocket_Reuse_SHARED,
	NULL,
	UPnPOnPostMX_MSEARCH_SendOK,
	mss);
	
	ILibChain_SafeAdd_SubChain(mss->Chain, subChain);
	mss->SubChain = subChain;
	
	// Search for root device
	if (STLength == 15 && memcmp(ST, "upnp:rootdevice", 15) == 0)
	{
		UPnPBuildSendSsdpResponsePacket(response_socket, upnp, (struct sockaddr*)&(mss->localIPAddress), (struct sockaddr*)&(mss->dest_addr), 0, "::upnp:rootdevice", "upnp:rootdevice", "");
	}
	// Search for everything
	else if (STLength == 8 && memcmp(ST, "ssdp:all", 8) == 0)
	{
		rcode = UPnPBuildSendSsdpResponsePacket(response_socket, upnp, (struct sockaddr*)&(mss->localIPAddress), (struct sockaddr*)&(mss->dest_addr), 0, "::upnp:rootdevice", "upnp:rootdevice", "");
		rcode = UPnPBuildSendSsdpResponsePacket(response_socket, upnp, (struct sockaddr*)&(mss->localIPAddress), (struct sockaddr*)&(mss->dest_addr), 0, "", upnp->UUID, "");
		rcode = UPnPBuildSendSsdpResponsePacket(response_socket, upnp, (struct sockaddr*)&(mss->localIPAddress), (struct sockaddr*)&(mss->dest_addr), 0, "::urn:schemas-upnp-org:device:Sample:1", "urn:schemas-upnp-org:device:Sample:1", "");
		rcode = UPnPBuildSendSsdpResponsePacket(response_socket, upnp, (struct sockaddr*)&(mss->localIPAddress), (struct sockaddr*)&(mss->dest_addr), 0, "::urn:schemas-upnp-org:service::1", "urn:schemas-upnp-org:service::1", "");
		
	}
	else if (STLength == (int)strlen(upnp->UUID) && memcmp(ST,upnp->UUID,(int)strlen(upnp->UUID))==0)
	{
		rcode = UPnPBuildSendSsdpResponsePacket(response_socket, upnp, (struct sockaddr*)&(mss->localIPAddress), (struct sockaddr*)&(mss->dest_addr), 0,"",upnp->UUID,"");
	}
	else if (STLength >= 35 && memcmp(ST,"urn:schemas-upnp-org:device:Sample:",35)==0 && atoi(ST+35)<=1)
	{
		rcode = UPnPBuildSendSsdpResponsePacket(response_socket, upnp, (struct sockaddr*)&(mss->localIPAddress), (struct sockaddr*)&(mss->dest_addr), 0, "::urn:schemas-upnp-org:device:Sample:1", ST, "");
	}
	else if (STLength >= 30 && memcmp(ST,"urn:schemas-upnp-org:service::",30)==0 && atoi(ST+30)<=1)
	{
		rcode = UPnPBuildSendSsdpResponsePacket(response_socket, upnp, (struct sockaddr*)&(mss->localIPAddress), (struct sockaddr*)&(mss->dest_addr), 0, "::urn:schemas-upnp-org:service::1", ST, "");
	}
	
	
	if (rcode == 0)
	{
		ILibChain_SafeRemove_SubChain(mss->Chain, subChain);
		free(mss->ST);
		free(mss);
	}
}

void UPnPProcessMSEARCH(struct UPnPDataObject *upnp, struct packetheader *packet)
{
	char* ST = NULL;
	unsigned long MXVal = 0;
	int STLength = 0, MANOK = 0, MXOK = 0, MX;
	struct packetheader_field_node *node;
	struct MSEARCH_state *mss = NULL;
	
	if (memcmp(packet->DirectiveObj, "*", 1)==0)
	{
		if (memcmp(packet->Version, "1.1", 3)==0)
		{
			node = packet->FirstField;
			while(node!=NULL)
			{
				if (node->FieldLength==2 && strncasecmp(node->Field,"ST",2)==0)
				{
					// This is what is being searched for
					if ((ST = (char*)malloc(1 + node->FieldDataLength)) == NULL) ILIBCRITICALEXIT(254);
					memcpy(ST, node->FieldData, node->FieldDataLength);
					ST[node->FieldDataLength] = 0;
					STLength = node->FieldDataLength;
				}
				else if (node->FieldLength == 3 && strncasecmp(node->Field, "MAN", 3) == 0 && memcmp(node->FieldData, "\"ssdp:discover\"", 15) == 0)
				{
					// This is a required header field
					MANOK = 1;
				}
				else if (node->FieldLength == 2 && strncasecmp(node->Field, "MX", 2) == 0 && ILibGetULong(node->FieldData, node->FieldDataLength, &MXVal) == 0)
				{
					// If the timeout value specified is greater than 10 seconds, just force it down to 10 seconds
					MXOK = 1;
					MXVal = MXVal>10?10:MXVal;
				}
				node = node->NextField;
			}
			if (MANOK != 0 && MXOK != 0)
			{
				if (MXVal == 0)
				{
					MX = 0;
				}
				else
				{
					// The timeout value should be a random number between 0 and the specified value
					MX = (int)(0 + ((unsigned short)rand() % MXVal));
				}
				if ((mss = (struct MSEARCH_state*)malloc(sizeof(struct MSEARCH_state))) == NULL) ILIBCRITICALEXIT(254);
				mss->ST = ST;
				mss->STLength = STLength;
				mss->upnp = upnp;
				memcpy(&(mss->dest_addr), &(packet->Source), sizeof(struct sockaddr_in6));
				memcpy(&(mss->localIPAddress), &(packet->ReceivingAddress), sizeof(struct sockaddr_in6));
				mss->Chain = upnp->Chain;
				
				// Register for a timed callback, so we can respond later
				ILibLifeTime_Add(upnp->WebServerTimer, mss, MX, &UPnPPostMX_MSEARCH, &UPnPPostMX_Destroy);
			}
			else
			{
				free(ST);
			}
		}
	}
}

#define UPnPDispatch_ImportedService_turn(buffer,offset,bufferLength, session)\
{\
	if (UPnPFP_ImportedService_turn == NULL)\
	UPnPResponse_Error(session,501,"No Function Handler");\
	else\
	UPnPFP_ImportedService_turn((void*)session);\
}



int UPnPProcessPOST(struct ILibWebServer_Session *session, struct packetheader* header, char *bodyBuffer, int offset, int bodyBufferLength)
{
	struct packetheader_field_node *f = header->FirstField;
	char* HOST;
	char* SOAPACTION = NULL;
	int SOAPACTIONLength = 0;
	struct parser_result *r, *r2;
	struct parser_result_field *prf;
	int RetVal = 0;
	
	// Iterate through all the HTTP Headers
	while(f!=NULL)
	{
		if (f->FieldLength == 4 && strncasecmp(f->Field, "HOST", 4) == 0)
		{
			HOST = f->FieldData;
		}
		else if (f->FieldLength == 10 && strncasecmp(f->Field, "SOAPACTION", 10) == 0)
		{
			r = ILibParseString(f->FieldData, 0, f->FieldDataLength, "#", 1);
			SOAPACTION = r->LastResult->data;
			SOAPACTIONLength = r->LastResult->datalength - 1;
			ILibDestructParserResults(r);
		}
		else if (f->FieldLength == 10 && strncasecmp(f->Field, "USER-AGENT", 10) == 0)
		{
			// Check UPnP version of the Control Point which invoked us
			r = ILibParseString(f->FieldData, 0, f->FieldDataLength, " ", 1);
			prf = r->FirstResult;
			while(prf!=NULL)
			{
				if (prf->datalength>5 && memcmp(prf->data, "UPnP/", 5)==0)
				{
					r2 = ILibParseString(prf->data + 5, 0, prf->datalength - 5, ".", 1);
					r2->FirstResult->data[r2->FirstResult->datalength] = 0;
					r2->LastResult->data[r2->LastResult->datalength] = 0;
					if (atoi(r2->FirstResult->data) == 1 && atoi(r2->LastResult->data) > 0)
					{
						session->Reserved9 = 1;
					}
					ILibDestructParserResults(r2);
				}
				prf = prf->NextResult;
			}
			ILibDestructParserResults(r);
		}
		f = f->NextField;
	}
	if (header->DirectiveObjLength==24 && memcmp((header->DirectiveObj)+1,"ImportedService/control",23)==0)
	{
		if (SOAPACTIONLength==4 && memcmp(SOAPACTION,"turn",4)==0)
		{
			UPnPDispatch_ImportedService_turn(bodyBuffer, offset, bodyBufferLength, session);
		}
		else
		{
			RetVal=1;
		}
	}
	else
	{
		RetVal=1;
	}
	
	return(RetVal);
}
struct SubscriberInfo* UPnPRemoveSubscriberInfo(struct SubscriberInfo **Head, int *TotalSubscribers, char* SID, int SIDLength)
{
	struct SubscriberInfo *info = *Head;
	while(info != NULL)
	{
		if (info->SIDLength == SIDLength && memcmp(info->SID, SID, SIDLength) == 0)
		{
			if (info->Previous) info->Previous->Next = info->Next; else *Head = info->Next;
			if (info->Next) info->Next->Previous = info->Previous;
			break;
		}
		info = info->Next;
	}
	if (info != NULL)
	{
		info->Previous = NULL;
		info->Next = NULL;
		--(*TotalSubscribers);
	}
	return(info);
}

#define UPnPDestructSubscriberInfo(info)\
{\
	free(info->Path);\
	free(info->SID);\
	free(info);\
}

#define UPnPDestructEventObject(EvObject)\
{\
	free(EvObject->PacketBody);\
	free(EvObject);\
}

#define UPnPDestructEventDataObject(EvData)\
{\
	free(EvData);\
}

void UPnPExpireSubscriberInfo(struct UPnPDataObject *d, struct SubscriberInfo *info)
{
	struct SubscriberInfo *t = info;
	while(t->Previous != NULL) { t = t->Previous; }
	if (d->HeadSubscriberPtr_ImportedService==t)
	{
		--(d->NumberOfSubscribers_ImportedService);
	}
	
	
	if (info->Previous != NULL)
	{
		// This is not the Head
		info->Previous->Next = info->Next;
		if (info->Next != NULL) { info->Next->Previous = info->Previous; }
	}
	else
	{
		// This is the Head
		if (d->HeadSubscriberPtr_ImportedService==info)
		{
			d->HeadSubscriberPtr_ImportedService = info->Next;
			if (info->Next!=NULL)
			{
				info->Next->Previous = NULL;
			}
		}
		else 
		{
			// Error
			return;
		}
		
	}
	--info->RefCount;
	if (info->RefCount == 0) { UPnPDestructSubscriberInfo(info); }
}

int UPnPSubscriptionExpired(struct SubscriberInfo *info)
{
	int RetVal = 0;
	struct timeval tv;
	gettimeofday(&tv, NULL);
	if ((info->RenewByTime).tv_sec < tv.tv_sec) { RetVal = -1; }
	return(RetVal);
}

void UPnPGetInitialEventBody_ImportedService(struct UPnPDataObject *UPnPObject,char ** body, int *bodylength)
{
	int TempLength;
	TempLength = (int)(31+(int)strlen(UPnPObject->ImportedService_unTourComplet));
	if ((*body = (char*)malloc(sizeof(char) * TempLength)) == NULL) ILIBCRITICALEXIT(254);
	*bodylength = snprintf(*body, sizeof(char) * TempLength, "unTourComplet>%s</unTourComplet",UPnPObject->ImportedService_unTourComplet);
}


void UPnPProcessUNSUBSCRIBE(struct packetheader *header, struct ILibWebServer_Session *session)
{
	char* SID = NULL;
	int SIDLength = 0;
	struct SubscriberInfo *Info;
	struct packetheader_field_node *f;
	char* packet;
	int packetlength;
	if ((packet = (char*)malloc(50)) == NULL) ILIBCRITICALEXIT(254);
	
	// Iterate through all the HTTP headers
	f = header->FirstField;
	while(f != NULL)
	{
		if (f->FieldLength == 3)
		{
			if (strncasecmp(f->Field, "SID", 3) == 0)
			{
				// Get the Subscription ID
				SID = f->FieldData;
				SIDLength = f->FieldDataLength;
			}
		}
		f = f->NextField;
	}
	sem_wait(&(((struct UPnPDataObject*)session->User)->EventLock));
	if (header->DirectiveObjLength==22 && memcmp(header->DirectiveObj + 1,"ImportedService/event",21)==0)
	{
		Info = UPnPRemoveSubscriberInfo(&(((struct UPnPDataObject*)session->User)->HeadSubscriberPtr_ImportedService),&(((struct UPnPDataObject*)session->User)->NumberOfSubscribers_ImportedService),SID,SIDLength);
		if (Info != NULL)
		{
			--Info->RefCount;
			if (Info->RefCount == 0)
			{
				UPnPDestructSubscriberInfo(Info);
			}
			packetlength = snprintf(packet, 50, "HTTP/1.1 %d %s\r\nContent-Length: 0\r\n\r\n", 200, "OK");
			ILibWebServer_Send_Raw(session, packet, packetlength, 0, 1);
		}
		else
		{
			packetlength = snprintf(packet, 50, "HTTP/1.1 %d %s\r\nContent-Length: 0\r\n\r\n", 412, "Invalid SID");
			ILibWebServer_Send_Raw(session, packet, packetlength, 0, 1);
		}
	}
	
	sem_post(&(((struct UPnPDataObject*)session->User)->EventLock));
}

void UPnPTryToSubscribe(char* ServiceName, long Timeout, char* URL, int URLLength, struct ILibWebServer_Session *session)
{
	int *TotalSubscribers = NULL;
	struct SubscriberInfo **HeadPtr = NULL;
	struct SubscriberInfo *NewSubscriber, *TempSubscriber;
	int SIDNumber, rnumber;
	char *SID;
	char *TempString;
	int TempStringLength;
	char *TempString2;
	long TempLong;
	char *packet;
	int packetlength;
	char* path;
	size_t len;
	
	char* escapedURI;
	int escapedURILength;
	
	char *packetbody = NULL;
	int packetbodyLength = 0;
	
	struct parser_result *p;
	struct parser_result *p2;
	
	struct UPnPDataObject *dataObject = (struct UPnPDataObject*)session->User;
	
	if (strncmp(ServiceName,"ImportedService",15)==0)
	{
		TotalSubscribers = &(dataObject->NumberOfSubscribers_ImportedService);
		HeadPtr = &(dataObject->HeadSubscriberPtr_ImportedService);
	}
	
	
	if (*HeadPtr!=NULL)
	{
		NewSubscriber = *HeadPtr;
		while(NewSubscriber != NULL)
		{
			if (UPnPSubscriptionExpired(NewSubscriber) != 0)
			{
				TempSubscriber = NewSubscriber->Next;
				NewSubscriber = UPnPRemoveSubscriberInfo(HeadPtr, TotalSubscribers, NewSubscriber->SID, NewSubscriber->SIDLength);
				UPnPDestructSubscriberInfo(NewSubscriber);
				NewSubscriber = TempSubscriber;
			}
			else
			{
				NewSubscriber = NewSubscriber->Next;
			}
		}
	}
	
	// The Maximum number of subscribers can be bounded
	if (*TotalSubscribers < 10)
	{
		if ((NewSubscriber = (struct SubscriberInfo*)malloc(sizeof(struct SubscriberInfo))) == NULL) ILIBCRITICALEXIT(254);
		memset(NewSubscriber, 0, sizeof(struct SubscriberInfo));
		
		// The SID must be globally unique, so lets generate it using a bunch of random hex characters
		if ((SID = (char*)malloc(43)) == NULL) ILIBCRITICALEXIT(254);
		memset(SID, 0, 38);
		snprintf(SID, 43, "uuid:");
		for(SIDNumber = 5; SIDNumber <= 12; ++SIDNumber)
		{
			rnumber = rand() % 16;
			snprintf(SID + SIDNumber, 43 - SIDNumber, "%x", rnumber);
		}
		snprintf(SID + SIDNumber, 43 - SIDNumber, "-");
		for(SIDNumber = 14; SIDNumber <= 17; ++SIDNumber)
		{
			rnumber = rand()%16;
			snprintf(SID + SIDNumber, 43 - SIDNumber, "%x", rnumber);
		}
		snprintf(SID + SIDNumber, 43 - SIDNumber, "-");
		for(SIDNumber = 19; SIDNumber <= 22; ++SIDNumber)
		{
			rnumber = rand()%16;
			snprintf(SID + SIDNumber, 43 - SIDNumber, "%x", rnumber);
		}
		snprintf(SID + SIDNumber, 43 - SIDNumber, "-");
		for(SIDNumber = 24; SIDNumber <= 27; ++SIDNumber)
		{
			rnumber = rand()%16;
			snprintf(SID + SIDNumber, 43 - SIDNumber, "%x", rnumber);
		}
		snprintf(SID + SIDNumber, 43 - SIDNumber, "-");
		for(SIDNumber = 29; SIDNumber <= 40; ++SIDNumber)
		{
			rnumber = rand()%16;
			snprintf(SID + SIDNumber, 43 - SIDNumber, "%x", rnumber);
		}
		
		p = ILibParseString(URL, 0, URLLength, "://", 3);
		if (p->NumResults == 1)
		{
			ILibWebServer_Send_Raw(session, "HTTP/1.1 412 Precondition Failed\r\nContent-Length: 0\r\n\r\n", 55, 1, 1);
			ILibDestructParserResults(p);
			return;
		}
		TempString = p->LastResult->data;
		TempStringLength = p->LastResult->datalength;
		ILibDestructParserResults(p);
		p = ILibParseString(TempString, 0, TempStringLength,"/", 1);
		p2 = ILibParseString(p->FirstResult->data, 0, p->FirstResult->datalength, ":", 1);
		if ((TempString2 = (char*)malloc(1 + sizeof(char) * p2->FirstResult->datalength)) == NULL) ILIBCRITICALEXIT(254);
		memcpy(TempString2, p2->FirstResult->data, p2->FirstResult->datalength);
		TempString2[p2->FirstResult->datalength] = '\0';
		NewSubscriber->Address = inet_addr(TempString2);
		if (p2->NumResults == 1)
		{
			NewSubscriber->Port = 80;
			if ((path = (char*)malloc(1+TempStringLength - p2->FirstResult->datalength -1)) == NULL) ILIBCRITICALEXIT(254);
			memcpy(path,TempString + p2->FirstResult->datalength,TempStringLength - p2->FirstResult->datalength -1);
			path[TempStringLength - p2->FirstResult->datalength - 1] = '\0';
			NewSubscriber->Path = path;
			NewSubscriber->PathLength = (int)strlen(path);
		}
		else
		{
			ILibGetLong(p2->LastResult->data,p2->LastResult->datalength,&TempLong);
			NewSubscriber->Port = (unsigned short)TempLong;
			if (TempStringLength == p->FirstResult->datalength)
			{
				if ((path = (char*)malloc(2)) == NULL) ILIBCRITICALEXIT(254);
				memcpy(path, "/", 1);
				path[1] = '\0';
			}
			else
			{
				if ((path = (char*)malloc(1 + TempStringLength - p->FirstResult->datalength - 1)) == NULL) ILIBCRITICALEXIT(254);
				memcpy(path,TempString + p->FirstResult->datalength,TempStringLength - p->FirstResult->datalength - 1);
				path[TempStringLength - p->FirstResult->datalength - 1] = '\0';
			}
			NewSubscriber->Path = path;
			NewSubscriber->PathLength = (int)strlen(path);
		}
		ILibDestructParserResults(p);
		ILibDestructParserResults(p2);
		free(TempString2);
		
		if ((escapedURI = (char*)malloc(ILibHTTPEscapeLength(NewSubscriber->Path))) == NULL) ILIBCRITICALEXIT(254);
		escapedURILength = ILibHTTPEscape(escapedURI, NewSubscriber->Path);
		
		free(NewSubscriber->Path);
		NewSubscriber->Path = escapedURI;
		NewSubscriber->PathLength = escapedURILength;
		
		NewSubscriber->RefCount = 1;
		NewSubscriber->Disposing = 0;
		NewSubscriber->Previous = NULL;
		NewSubscriber->SID = SID;
		NewSubscriber->SIDLength = (int)strlen(SID);
		NewSubscriber->SEQ = 0;
		
		// Determine what the subscription renewal cycle is
		gettimeofday(&(NewSubscriber->RenewByTime),NULL);
		(NewSubscriber->RenewByTime).tv_sec += (int)Timeout;
		
		NewSubscriber->Next = *HeadPtr;
		if (*HeadPtr!=NULL) {(*HeadPtr)->Previous = NewSubscriber;}
		*HeadPtr = NewSubscriber;
		++(*TotalSubscribers);
		LVL3DEBUG(printf("\r\n\r\nSubscribed [%s] %d.%d.%d.%d:%d FOR %d Duration\r\n",NewSubscriber->SID,(NewSubscriber->Address)&0xFF,(NewSubscriber->Address>>8)&0xFF,(NewSubscriber->Address>>16)&0xFF,(NewSubscriber->Address>>24)&0xFF,NewSubscriber->Port,Timeout);)
		LVL3DEBUG(printf("TIMESTAMP: %d <%d>\r\n\r\n",(NewSubscriber->RenewByTime).tv_sec-Timeout,NewSubscriber);)
		
		len = 134 + (int)strlen(SID) + (int)strlen(UPnPPLATFORM) + 4;
		if ((packet = (char*)malloc(len)) == NULL) ILIBCRITICALEXIT(254);
		packetlength = snprintf(packet, len, "HTTP/1.1 200 OK\r\nSERVER: %s, UPnP/1.0, MicroStack/1.0.5329\r\nSID: %s\r\nTIMEOUT: Second-%ld\r\nContent-Length: 0\r\n\r\n",UPnPPLATFORM,SID,Timeout);
		if (strcmp(ServiceName,"ImportedService")==0)
		{
			UPnPGetInitialEventBody_ImportedService(dataObject,&packetbody,&packetbodyLength);
		}
		
		if (packetbody != NULL)
		{
			ILibWebServer_Send_Raw(session, packet, packetlength, 0, 1);
			UPnPSendEvent_Body(dataObject, packetbody, packetbodyLength, NewSubscriber);
			free(packetbody);
		} 
	}
	else
	{
		// Too many subscribers
		ILibWebServer_Send_Raw(session,"HTTP/1.1 412 Too Many Subscribers\r\nContent-Length: 0\r\n\r\n",56,1,1);
	}
}

void UPnPSubscribeEvents(char* path, int pathlength, char* Timeout, int TimeoutLength, char* URL, int URLLength, struct ILibWebServer_Session* session)
{
	long TimeoutVal;
	char* buffer;
	if ((buffer = (char*)malloc(1 + sizeof(char)*pathlength)) == NULL) ILIBCRITICALEXIT(254);
	
	ILibGetLong(Timeout, TimeoutLength, &TimeoutVal);
	memcpy(buffer, path, pathlength);
	buffer[pathlength] = '\0';
	free(buffer);
	if (TimeoutVal>UPnP_MAX_SUBSCRIPTION_TIMEOUT) { TimeoutVal = UPnP_MAX_SUBSCRIPTION_TIMEOUT; }
	if (pathlength==22 && memcmp(path+1,"ImportedService/event",21)==0)
	{
		UPnPTryToSubscribe("ImportedService",TimeoutVal,URL,URLLength,session);
	}
	else
	{
		ILibWebServer_Send_Raw(session,"HTTP/1.1 412 Invalid Service Name\r\nContent-Length: 0\r\n\r\n",56,1,1);
	}
	
}

void UPnPRenewEvents(char* path, int pathlength, char *_SID,int SIDLength, char* Timeout, int TimeoutLength, struct ILibWebServer_Session *ReaderObject)
{
	struct SubscriberInfo *info = NULL;
	long TimeoutVal;
	struct timeval tv;
	char* packet;
	int packetlength;
	char* SID;
	size_t len;
	
	if ((SID = (char*)malloc(SIDLength + 1)) == NULL) ILIBCRITICALEXIT(254);
	memcpy(SID, _SID, SIDLength);
	SID[SIDLength] = '\0';
	
	LVL3DEBUG(gettimeofday(&tv, NULL);)
	LVL3DEBUG(printf("\r\n\r\nTIMESTAMP: %d\r\n", tv.tv_sec);)
	LVL3DEBUG(printf("SUBSCRIBER [%s] attempting to Renew Events for %s Duration [", SID, Timeout);)
	if (pathlength==22 && memcmp(path+1,"ImportedService/event",21)==0)
	{
		info = ((struct UPnPDataObject*)ReaderObject->User)->HeadSubscriberPtr_ImportedService;
	}
	
	
	// Find this SID in the subscriber list, and recalculate the expiration timeout
	while(info != NULL && strcmp(info->SID,SID) != 0)
	{
		info = info->Next;
	}
	if (info != NULL)
	{
		ILibGetLong(Timeout, TimeoutLength, &TimeoutVal);
		if (TimeoutVal>UPnP_MAX_SUBSCRIPTION_TIMEOUT) {TimeoutVal = UPnP_MAX_SUBSCRIPTION_TIMEOUT;}
		
		gettimeofday(&tv,NULL);
		(info->RenewByTime).tv_sec = tv.tv_sec + TimeoutVal;
		
		len = 134 + strlen(SID) + 4;
		if ((packet = (char*)malloc(len)) == NULL) ILIBCRITICALEXIT(254);
		packetlength = snprintf(packet, len, "HTTP/1.1 200 OK\r\nSERVER: %s, UPnP/1.0, MicroStack/1.0.5329\r\nSID: %s\r\nTIMEOUT: Second-%ld\r\nContent-Length: 0\r\n\r\n",UPnPPLATFORM,SID,TimeoutVal);
		ILibWebServer_Send_Raw(ReaderObject, packet, packetlength, 0, 1);
		LVL3DEBUG(printf("OK] {%d} <%d>\r\n\r\n", TimeoutVal, info);)
	}
	else
	{
		LVL3DEBUG(printf("FAILED]\r\n\r\n");)
		ILibWebServer_Send_Raw(ReaderObject, "HTTP/1.1 412 Precondition Failed\r\nContent-Length: 0\r\n\r\n", 55, 1, 1);
	}
	free(SID);
}

void UPnPProcessSUBSCRIBE(struct packetheader *header, struct ILibWebServer_Session *session)
{
	char* SID = NULL;
	int SIDLength = 0;
	char* Timeout = NULL;
	int TimeoutLength = 0;
	char* URL = NULL;
	int URLLength = 0;
	struct parser_result *p;
	struct packetheader_field_node *f;
	
	// Iterate through all the HTTP Headers
	f = header->FirstField;
	while(f!=NULL)
	{
		if (f->FieldLength==3 && strncasecmp(f->Field, "SID", 3) == 0)
		{
			// Get the Subscription ID
			SID = f->FieldData;
			SIDLength = f->FieldDataLength;
		}
		else if (f->FieldLength == 8 && strncasecmp(f->Field, "Callback", 8) == 0)
		{
			// Get the Callback URL
			URL = f->FieldData;
			URLLength = f->FieldDataLength;
		}
		else if (f->FieldLength == 7 && strncasecmp(f->Field, "Timeout", 7) == 0)
		{
			// Get the requested timeout value
			Timeout = f->FieldData;
			TimeoutLength = f->FieldDataLength;
		}
		f = f->NextField;
	}
	if (Timeout == NULL)
	{
		// It a timeout wasn't specified, force it to a specific value
		Timeout = "7200";
		TimeoutLength = 4;
	}
	else
	{
		p = ILibParseString(Timeout, 0, TimeoutLength, "-", 1);
		if (p->NumResults == 2)
		{
			Timeout = p->LastResult->data;
			TimeoutLength = p->LastResult->datalength;
			if (TimeoutLength == 8 && strncasecmp(Timeout, "INFINITE", 8) == 0)
			{
				// Infinite timeouts will cause problems, so we don't allow it
				Timeout = "7200";
				TimeoutLength = 4;
			}
		}
		else
		{
			Timeout = "7200";
			TimeoutLength = 4;
		}
		ILibDestructParserResults(p);
	}
	if (SID == NULL)
	{
		// If not SID was specified, this is a subscription request
		// Subscribe
		UPnPSubscribeEvents(header->DirectiveObj, header->DirectiveObjLength, Timeout, TimeoutLength, URL, URLLength, session);
	}
	else
	{
		// If a SID was specified, it is a renewal request for an existing subscription
		// Renew
		UPnPRenewEvents(header->DirectiveObj, header->DirectiveObjLength, SID, SIDLength, Timeout, TimeoutLength, session);
	}
}
void UPnPProcessHTTPPacket(struct ILibWebServer_Session *session, struct packetheader* header, char *bodyBuffer, int offset, int bodyBufferLength)
{
	struct UPnPDataObject *dataObject = (struct UPnPDataObject*)session->User;
	#if defined(WIN32) || defined(_WIN32_WCE)
	char *responseHeader = "\r\nCONTENT-TYPE:  text/xml; charset=\"utf-8\"\r\nServer: WINDOWS, UPnP/1.0, MicroStack/1.0.5329";
	#elif defined(__SYMBIAN32__)
	char *responseHeader = "\r\nCONTENT-TYPE:  text/xml; charset=\"utf-8\"\r\nServer: SYMBIAN, UPnP/1.0, MicroStack/1.0.5329";
	#else
	char *responseHeader = "\r\nCONTENT-TYPE:  text/xml; charset=\"utf-8\"\r\nServer: POSIX, UPnP/1.0, MicroStack/1.0.5329";
	#endif
	char *errorTemplate = "HTTP/1.1 %d %s\r\nServer: %s, UPnP/1.0, MicroStack/1.0.5329\r\nContent-Length: 0\r\n\r\n";
	char *errorPacket;
	int errorPacketLength;
	char *buffer;
	
	LVL3DEBUG(errorPacketLength = ILibGetRawPacket(header, &errorPacket);)
	LVL3DEBUG(printf("%s\r\n",errorPacket);)
	LVL3DEBUG(free(errorPacket);)			
	
	
	if (header->DirectiveLength == 4 && memcmp(header->Directive,"HEAD", 4) == 0)
	{
		if (header->DirectiveObjLength == strlen(UPnPXmlLocation) && memcmp(header->DirectiveObj, UPnPXmlLocation, strlen(UPnPXmlLocation)) == 0)
		{
			// A HEAD request for the device description document.
			// We stream the document back, so we don't return content length or anything because the actual response won't have it either
			ILibWebServer_StreamHeader_Raw(session, 200, "OK", responseHeader, 1);
			ILibWebServer_StreamBody(session, NULL, 0, ILibAsyncSocket_MemoryOwnership_STATIC, 1);
		}
		else if (header->DirectiveObjLength==25 && memcmp((header->DirectiveObj)+1,"ImportedService/scpd.xml",24)==0)
		{
			ILibWebServer_StreamHeader_Raw(session,200,"OK",responseHeader,1);
			ILibWebServer_StreamBody(session,NULL,0,ILibAsyncSocket_MemoryOwnership_STATIC,1);
		}
		
		else
		{
			// A HEAD request for something we don't have
			if ((errorPacket = (char*)malloc(128)) == NULL) ILIBCRITICALEXIT(254);
			errorPacketLength = snprintf(errorPacket, 128, errorTemplate, 404, "File Not Found", UPnPPLATFORM);
			ILibWebServer_Send_Raw(session, errorPacket, errorPacketLength, 0, 1);
		}
	}
	else if (header->DirectiveLength == 3 && memcmp(header->Directive, "GET", 3) == 0)
	{
		if (header->DirectiveObjLength == strlen(UPnPXmlLocation) && memcmp(header->DirectiveObj, UPnPXmlLocation, strlen(UPnPXmlLocation)) == 0)
		{
			// A GET Request for the device description document, so lets stream it back to the client
			ILibWebServer_StreamHeader_Raw(session, 200, "OK", responseHeader, 1);
			ILibWebServer_StreamBody(session, dataObject->DeviceDescription, dataObject->DeviceDescriptionLength, 1, 1);
		}
		else if (header->DirectiveObjLength==25 && memcmp((header->DirectiveObj)+1,"ImportedService/scpd.xml",24)==0)
		{
			buffer = ILibDecompressString((unsigned char*)UPnPImportedServiceDescription,UPnPImportedServiceDescriptionLength,UPnPImportedServiceDescriptionLengthUX);
			ILibWebServer_Send_Raw(session,buffer,UPnPImportedServiceDescriptionLengthUX,0,1);
		}
		
		else
		{
			// A GET Request for something we don't have
			if ((errorPacket = (char*)malloc(128)) == NULL) ILIBCRITICALEXIT(254);
			errorPacketLength = snprintf(errorPacket, 128, errorTemplate, 404, "File Not Found", UPnPPLATFORM);
			ILibWebServer_Send_Raw(session, errorPacket, errorPacketLength, 0, 1);
		}
	}
	else if (header->DirectiveLength == 4 && memcmp(header->Directive,"POST",4) == 0)
	{
		// Defer Control to the POST Handler
		if (UPnPProcessPOST(session, header, bodyBuffer, offset, bodyBufferLength) != 0)
		{
			// A POST for an action that doesn't exist
			UPnPResponse_Error(session, 401, "Invalid Action");
		}
	}
	else if (header->DirectiveLength == 9 && memcmp(header->Directive, "SUBSCRIBE" ,9) == 0)
	{
		// Subscription Handler
		UPnPProcessSUBSCRIBE(header,session);
	}
	else if (header->DirectiveLength == 11 && memcmp(header->Directive, "UNSUBSCRIBE", 11) == 0)
	{
		// UnSubscribe Handler
		UPnPProcessUNSUBSCRIBE(header,session);
	}	else
	{
		// The client tried something we didn't expect/support
		if ((errorPacket = (char*)malloc(128)) == NULL) ILIBCRITICALEXIT(254);
		errorPacketLength = snprintf(errorPacket, 128, errorTemplate, 400, "Bad Request", UPnPPLATFORM);
		ILibWebServer_Send_Raw(session, errorPacket, errorPacketLength, ILibAsyncSocket_MemoryOwnership_CHAIN, 1);
	}
}
void UPnPFragmentedSendNotify_Destroy(void *data);
void UPnPMasterPreSelect(void* object, void *socketset, void *writeset, void *errorset, int* blocktime)
{
	int i;
	struct UPnPDataObject *UPnPObject = (struct UPnPDataObject*)object;	
	struct UPnPFragmentNotifyStruct *f;
	int timeout;
	UNREFERENCED_PARAMETER( socketset );
	UNREFERENCED_PARAMETER( writeset );
	UNREFERENCED_PARAMETER( errorset );
	UNREFERENCED_PARAMETER( blocktime );
	
	if (UPnPObject->InitialNotify == 0)
	{
		// The initial "HELLO" packets were not sent yet, so lets send them
		UPnPObject->InitialNotify = -1;
		
		// In case we were interrupted, we need to flush out the caches of
		// all the control points by sending a "byebye" first, to insure
		// control points don't ignore our "hello" packets thinking they are just
		// periodic re-advertisements.
		UPnPSendByeBye(UPnPObject);
		
		// PacketNumber 0 is the controller, for the rest of the packets. Send
		// one of these to send out an advertisement "group"
		if ((f = (struct UPnPFragmentNotifyStruct*)malloc(sizeof(struct UPnPFragmentNotifyStruct))) == NULL) ILIBCRITICALEXIT(254);
		f->packetNumber = 0;
		f->upnp = UPnPObject;
		
		// We need to inject some delay in these packets to space them out,
		// otherwise we could overflow the inbound buffer of the recipient, causing them
		// to lose packets. And UPnP/1.0 control points are not as robust as UPnP/1.1 control points,
		// so they need all the help they can get ;)
		timeout = (int)(0 + ((unsigned short)rand() % (500)));
		do { f->upnp->InitialNotify = rand(); } while (f->upnp->InitialNotify == 0);
		
		// Register for the timed callback, to actually send the packet
		ILibLifeTime_AddEx(f->upnp->WebServerTimer, f, timeout, &UPnPFragmentedSendNotify, &UPnPFragmentedSendNotify_Destroy);
	}
	
	if (UPnPObject->UpdateFlag != 0)
	{
		struct sockaddr_in any4;
		struct sockaddr_in6 any6;
		
		// Somebody told us that we should recheck our IP Address table, as one of them may have changed
		UPnPObject->UpdateFlag = 0;
		
		// Setup ANY addresses
		memset(&any4, 0, sizeof(struct sockaddr_in));
		any4.sin_family = AF_INET;
		any4.sin_port = htons(UPNP_PORT);
		memset(&any6, 0, sizeof(struct sockaddr_in6));
		any6.sin6_family = AF_INET6;
		any6.sin6_port = htons(UPNP_PORT);
		
		// Clear Sockets
		// Iterate through all the currently bound IPv4 addresses and release the sockets
		if (UPnPObject->AddressListV4 != NULL)
		{
			for (i = 0; i < UPnPObject->AddressListV4Length; ++i) ILibChain_SafeRemove(UPnPObject->Chain, UPnPObject->NOTIFY_SEND_socks[i]);
			free(UPnPObject->NOTIFY_SEND_socks);
			for (i = 0; i < UPnPObject->AddressListV4Length; ++i) ILibChain_SafeRemove(UPnPObject->Chain, UPnPObject->NOTIFY_RECEIVE_socks[i]);
			free(UPnPObject->NOTIFY_RECEIVE_socks);
			free(UPnPObject->AddressListV4);
		}
		if (UPnPObject->AddressListV6 != NULL)
		{
			for (i = 0; i < UPnPObject->AddressListV6Length; ++i) ILibChain_SafeRemove(UPnPObject->Chain, UPnPObject->NOTIFY_SEND_socks6[i]);
			free(UPnPObject->NOTIFY_SEND_socks6);
			for (i = 0; i < UPnPObject->AddressListV6Length; ++i) ILibChain_SafeRemove(UPnPObject->Chain, UPnPObject->NOTIFY_RECEIVE_socks6[i]);
			free(UPnPObject->NOTIFY_RECEIVE_socks6);
			free(UPnPObject->AddressListV6);
		}
		
		// Fetch a current list of ip addresses
		UPnPObject->AddressListV4Length = ILibGetLocalIPv4AddressList(&(UPnPObject->AddressListV4), 1);
		
		// Re-Initialize our SEND socket
		if ((UPnPObject->NOTIFY_SEND_socks = (void**)malloc(sizeof(void*)*(UPnPObject->AddressListV4Length))) == NULL) ILIBCRITICALEXIT(254);
		if ((UPnPObject->NOTIFY_RECEIVE_socks = (void**)malloc(sizeof(void*)*(UPnPObject->AddressListV4Length))) == NULL) ILIBCRITICALEXIT(254);
		
		// Test IPv6 support
		if (ILibDetectIPv6Support())
		{
			// Fetch the list of local IPv6 interfaces
			UPnPObject->AddressListV6Length = ILibGetLocalIPv6List(&(UPnPObject->AddressListV6));
			
			// Setup the IPv6 sockets
			if ((UPnPObject->NOTIFY_SEND_socks6 = (void**)malloc(sizeof(void*)*(UPnPObject->AddressListV6Length))) == NULL) ILIBCRITICALEXIT(254);
			if ((UPnPObject->NOTIFY_RECEIVE_socks6 = (void**)malloc(sizeof(void*)*(UPnPObject->AddressListV6Length))) == NULL) ILIBCRITICALEXIT(254);
		}
		
		// Iterate through all the current IP Addresses
		for (i = 0; i < UPnPObject->AddressListV4Length; ++i)
		{
			(UPnPObject->AddressListV4[i]).sin_port = 0; // Bind to ANY port for outbound packets
			UPnPObject->NOTIFY_SEND_socks[i] = ILibAsyncUDPSocket_CreateEx(
			UPnPObject->Chain,
			UPNP_MAX_SSDP_HEADER_SIZE,
			(struct sockaddr*)&any4,									// (struct sockaddr*)&(UPnPObject->AddressListV4[i]),
			ILibAsyncUDPSocket_Reuse_SHARED,
			NULL,
			NULL,
			UPnPObject);
			
			ILibAsyncUDPSocket_SetMulticastTTL(UPnPObject->NOTIFY_SEND_socks[i], UPNP_SSDP_TTL);
			ILibAsyncUDPSocket_SetMulticastLoopback(UPnPObject->NOTIFY_SEND_socks[i], 1);
			
			(UPnPObject->AddressListV4[i]).sin_port = htons(UPNP_PORT); // Bind to UPnP port for inbound packets
			UPnPObject->NOTIFY_RECEIVE_socks[i] = ILibAsyncUDPSocket_CreateEx(
			UPnPObject->Chain,
			UPNP_MAX_SSDP_HEADER_SIZE,
			(struct sockaddr*)&(UPnPObject->AddressListV4[i]),
			ILibAsyncUDPSocket_Reuse_SHARED,
			&UPnPSSDPSink,
			NULL,
			UPnPObject);
			
			ILibAsyncUDPSocket_JoinMulticastGroupV4(UPnPObject->NOTIFY_RECEIVE_socks[i], (struct sockaddr_in*)&(UPnPObject->MulticastAddrV4), (struct sockaddr*)&(UPnPObject->AddressListV4[i]));
			ILibAsyncUDPSocket_SetLocalInterface(UPnPObject->NOTIFY_RECEIVE_socks[i], (struct sockaddr*)&(UPnPObject->AddressListV4[i]));
			ILibAsyncUDPSocket_SetMulticastLoopback(UPnPObject->NOTIFY_RECEIVE_socks[i], 1);
		}
		
		if (UPnPObject->AddressListV6Length > 0)
		{
			// Iterate through all the current IPv6 interfaces
			for (i = 0; i < UPnPObject->AddressListV6Length; ++i)
			{
				(UPnPObject->AddressListV6[i]).sin6_port = 0;
				UPnPObject->NOTIFY_SEND_socks6[i] = ILibAsyncUDPSocket_CreateEx(
				UPnPObject->Chain,
				UPNP_MAX_SSDP_HEADER_SIZE,
				(struct sockaddr*)&(UPnPObject->AddressListV6[i]),
				ILibAsyncUDPSocket_Reuse_SHARED,
				NULL,
				NULL,
				UPnPObject);
				
				ILibAsyncUDPSocket_SetMulticastTTL(UPnPObject->NOTIFY_SEND_socks6[i], UPNP_SSDP_TTL);
				ILibAsyncUDPSocket_SetMulticastLoopback(UPnPObject->NOTIFY_SEND_socks6[i], 1);
				
				(UPnPObject->AddressListV6[i]).sin6_port = htons(UPNP_PORT); // Bind to UPnP port for inbound packets
				UPnPObject->NOTIFY_RECEIVE_socks6[i] = ILibAsyncUDPSocket_CreateEx(
				UPnPObject->Chain,
				UPNP_MAX_SSDP_HEADER_SIZE,
				(struct sockaddr*)&any6,							// (struct sockaddr*)&(UPnPObject->AddressListV6[i]),
				ILibAsyncUDPSocket_Reuse_SHARED,
				&UPnPSSDPSink,
				NULL,
				UPnPObject);
				
				if (ILibAsyncSocket_IsIPv6LinkLocal((struct sockaddr*)&(UPnPObject->AddressListV6[i])))
				{
					ILibAsyncUDPSocket_JoinMulticastGroupV6(UPnPObject->NOTIFY_RECEIVE_socks6[i], &(UPnPObject->MulticastAddrV6LL), UPnPObject->AddressListV6[i].sin6_scope_id);
				}
				else
				{
					ILibAsyncUDPSocket_JoinMulticastGroupV6(UPnPObject->NOTIFY_RECEIVE_socks6[i], &(UPnPObject->MulticastAddrV6SL), UPnPObject->AddressListV6[i].sin6_scope_id);
				}
				ILibAsyncUDPSocket_SetMulticastLoopback(UPnPObject->NOTIFY_RECEIVE_socks6[i], 1);
				ILibAsyncUDPSocket_SetLocalInterface(UPnPObject->NOTIFY_RECEIVE_socks6[i], (struct sockaddr*)&(UPnPObject->AddressListV6[i]));
			}
		}
		
		// Iterate through all the packet types, and re-broadcast
		for (i = 1; i <= 4; ++i)
		{
			if ((f = (struct UPnPFragmentNotifyStruct*)malloc(sizeof(struct UPnPFragmentNotifyStruct))) == NULL) ILIBCRITICALEXIT(254);
			f->packetNumber = i;
			f->upnp = UPnPObject;
			
			// Inject some random delay, to spread these packets out, to help prevent the inbound buffer of the recipient from overflowing, causing dropped packets.
			timeout = (int)(0 + ((unsigned short)rand() % (500)));
			ILibLifeTime_AddEx(f->upnp->WebServerTimer, f, timeout, &UPnPFragmentedSendNotify, &UPnPFragmentedSendNotify_Destroy);
		}
	}
}

void UPnPFragmentedSendNotify_Destroy(void *data)
{
	free(data);
}

void UPnPFragmentedSendNotify(void *data)
{
	int i,i2;
	int subsetRange;
	int timeout, timeout2;
	struct UPnPFragmentNotifyStruct *f;
	struct UPnPFragmentNotifyStruct *FNS = (struct UPnPFragmentNotifyStruct*)data;
	
	if (FNS->packetNumber == 0)
	{				
		subsetRange = 5000 / 5; // Make sure all our packets will get out within 5 seconds
		
		// Send the first "group"
		for (i2 = 0; i2 <= 4; ++i2)
		{
			if ((f = (struct UPnPFragmentNotifyStruct*)malloc(sizeof(struct UPnPFragmentNotifyStruct))) == NULL) ILIBCRITICALEXIT(254);
			f->packetNumber = i2 + 1;
			f->upnp = FNS->upnp;
			timeout2 = (rand() % subsetRange);
			ILibLifeTime_AddEx(FNS->upnp->WebServerTimer, f, timeout2, &UPnPFragmentedSendNotify, &UPnPFragmentedSendNotify_Destroy);
		}
		
		// Now Repeat this "group" after 7 seconds, to insure there is no overlap
		for (i2 = 0; i2 <= 4; ++i2)
		{
			if ((f = (struct UPnPFragmentNotifyStruct*)malloc(sizeof(struct UPnPFragmentNotifyStruct))) == NULL) ILIBCRITICALEXIT(254);
			f->packetNumber = i2 + 1;
			f->upnp = FNS->upnp;
			timeout2 = 7000 + (rand() % subsetRange);
			ILibLifeTime_AddEx(FNS->upnp->WebServerTimer, f, timeout2, &UPnPFragmentedSendNotify, &UPnPFragmentedSendNotify_Destroy);
		}
		
		// Calculate the next transmission window and spread the packets
		timeout = (int)((FNS->upnp->NotifyCycleTime / 4) + ((unsigned short)rand() % (FNS->upnp->NotifyCycleTime / 2 - FNS->upnp->NotifyCycleTime / 4)));
		ILibLifeTime_Add(FNS->upnp->WebServerTimer, FNS, timeout, &UPnPFragmentedSendNotify, &UPnPFragmentedSendNotify_Destroy);
	}
	
	for (i = 0; i < FNS->upnp->AddressListV4Length; ++i)
	{
		switch(FNS->packetNumber)
		{
			case 1:
			UPnPBuildSendSsdpNotifyPacket(FNS->upnp->NOTIFY_SEND_socks[i], FNS->upnp, (struct sockaddr*)&(FNS->upnp->AddressListV4[i]), 0, "::upnp:rootdevice", "upnp:rootdevice", "");
			break;
			case 2:
			UPnPBuildSendSsdpNotifyPacket(FNS->upnp->NOTIFY_SEND_socks[i], FNS->upnp, (struct sockaddr*)&(FNS->upnp->AddressListV4[i]), 0, "", "uuid:", FNS->upnp->UDN);
			break;
			case 3:
			UPnPBuildSendSsdpNotifyPacket(FNS->upnp->NOTIFY_SEND_socks[i], FNS->upnp, (struct sockaddr*)&(FNS->upnp->AddressListV4[i]), 0, "::urn:schemas-upnp-org:device:Sample:1", "urn:schemas-upnp-org:device:Sample:1", "");
			break;
			case 4:
			UPnPBuildSendSsdpNotifyPacket(FNS->upnp->NOTIFY_SEND_socks[i], FNS->upnp, (struct sockaddr*)&(FNS->upnp->AddressListV4[i]), 0, "::urn:schemas-upnp-org:service::1", "urn:schemas-upnp-org:service::1", "");
			break;
			
		}
	}
	
	for (i = 0; i < FNS->upnp->AddressListV6Length; ++i)
	{
		switch(FNS->packetNumber)
		{
			case 1:
			UPnPBuildSendSsdpNotifyPacket(FNS->upnp->NOTIFY_SEND_socks6[i], FNS->upnp, (struct sockaddr*)&(FNS->upnp->AddressListV6[i]), 0, "::upnp:rootdevice", "upnp:rootdevice", "");
			break;
			case 2:
			UPnPBuildSendSsdpNotifyPacket(FNS->upnp->NOTIFY_SEND_socks6[i], FNS->upnp, (struct sockaddr*)&(FNS->upnp->AddressListV6[i]), 0, "", "uuid:", FNS->upnp->UDN);
			break;
			case 3:
			UPnPBuildSendSsdpNotifyPacket(FNS->upnp->NOTIFY_SEND_socks6[i], FNS->upnp, (struct sockaddr*)&(FNS->upnp->AddressListV6[i]), 0, "::urn:schemas-upnp-org:device:Sample:1", "urn:schemas-upnp-org:device:Sample:1", "");
			break;
			case 4:
			UPnPBuildSendSsdpNotifyPacket(FNS->upnp->NOTIFY_SEND_socks6[i], FNS->upnp, (struct sockaddr*)&(FNS->upnp->AddressListV6[i]), 0, "::urn:schemas-upnp-org:service::1", "urn:schemas-upnp-org:service::1", "");
			break;
			
		}
	}
	
	if (FNS->packetNumber != 0) free(FNS);
}


void UPnPSendNotify(const struct UPnPDataObject *upnp)
{
	int i, i2;
	for (i=0;i<upnp->AddressListV4Length;++i)
	{
		for (i2=0; i2<2; i2++)
		{
			UPnPBuildSendSsdpNotifyPacket(upnp->NOTIFY_SEND_socks[i], upnp, (struct sockaddr*)&(upnp->AddressListV4[i]), 0, "::upnp:rootdevice", "upnp:rootdevice", "");
			UPnPBuildSendSsdpNotifyPacket(upnp->NOTIFY_SEND_socks[i], upnp, (struct sockaddr*)&(upnp->AddressListV4[i]), 0, "", "uuid:", upnp->UDN);
			UPnPBuildSendSsdpNotifyPacket(upnp->NOTIFY_SEND_socks[i], upnp, (struct sockaddr*)&(upnp->AddressListV4[i]), 0, "::urn:schemas-upnp-org:device:Sample:1", "urn:schemas-upnp-org:device:Sample:1", "");
			UPnPBuildSendSsdpNotifyPacket(upnp->NOTIFY_SEND_socks[i], upnp, (struct sockaddr*)&(upnp->AddressListV4[i]), 0, "::urn:schemas-upnp-org:service::1", "urn:schemas-upnp-org:service::1", "");
			
		}
	}
	for (i=0;i<upnp->AddressListV6Length;++i)
	{
		for (i2=0; i2<2; i2++)
		{
			UPnPBuildSendSsdpNotifyPacket(upnp->NOTIFY_SEND_socks6[i], upnp, (struct sockaddr*)&(upnp->AddressListV6[i]), 0, "::upnp:rootdevice", "upnp:rootdevice", "");
			UPnPBuildSendSsdpNotifyPacket(upnp->NOTIFY_SEND_socks6[i], upnp, (struct sockaddr*)&(upnp->AddressListV6[i]), 0, "", "uuid:", upnp->UDN);
			UPnPBuildSendSsdpNotifyPacket(upnp->NOTIFY_SEND_socks6[i], upnp, (struct sockaddr*)&(upnp->AddressListV6[i]), 0, "::urn:schemas-upnp-org:device:Sample:1", "urn:schemas-upnp-org:device:Sample:1", "");
			UPnPBuildSendSsdpNotifyPacket(upnp->NOTIFY_SEND_socks6[i], upnp, (struct sockaddr*)&(upnp->AddressListV6[i]), 0, "::urn:schemas-upnp-org:service::1", "urn:schemas-upnp-org:service::1", "");
			
		}
	}
}

int UPnPBuildSendSsdpByeByePacket(void* module, const struct UPnPDataObject *upnp, struct sockaddr* target, char* mcastgroup, char* USNex, char* NT, char* NTex, int DeviceID)
{
	int len;
	
	if (DeviceID == 0)
	{
		len = snprintf(ILibScratchPad, sizeof(ILibScratchPad), "NOTIFY * HTTP/1.1\r\nHOST: %s:1900\r\nNTS: ssdp:byebye\r\nUSN: uuid:%s%s\r\nNT: %s%s\r\nContent-Length: 0\r\n\r\n", mcastgroup, upnp->UDN, USNex, NT, NTex);
	}
	else
	{
		if (memcmp(NT, "uuid:", 5) == 0)
		{
			len = snprintf(ILibScratchPad, sizeof(ILibScratchPad), "NOTIFY * HTTP/1.1\r\nHOST: %s:1900\r\nNTS: ssdp:byebye\r\nUSN: uuid:%s_%d%s\r\nNT: %s%s_%d\r\nContent-Length: 0\r\n\r\n", mcastgroup, upnp->UDN, DeviceID, USNex, NT, NTex, DeviceID);
		}
		else
		{
			len = snprintf(ILibScratchPad, sizeof(ILibScratchPad), "NOTIFY * HTTP/1.1\r\nHOST: %s:1900\r\nNTS: ssdp:byebye\r\nUSN: uuid:%s_%d%s\r\nNT: %s%s\r\nContent-Length: 0\r\n\r\n", mcastgroup, upnp->UDN, DeviceID, USNex, NT, NTex);
		}
	}
	return ILibAsyncUDPSocket_SendTo(module, target, ILibScratchPad, len, ILibAsyncSocket_MemoryOwnership_USER);
}

void UPnPSendByeBye(const struct UPnPDataObject *upnp)
{
	int i, i2;
	struct sockaddr* t1;
	char* t2;
	
	for (i=0; i<upnp->AddressListV4Length; ++i)
	{	
		for (i2=0; i2<2; i2++)
		{
			UPnPBuildSendSsdpByeByePacket(upnp->NOTIFY_SEND_socks[i], upnp, (struct sockaddr*)&(upnp->MulticastAddrV4), UPNP_MCASTv4_GROUP, "::upnp:rootdevice", "upnp:rootdevice", "", 0);
			UPnPBuildSendSsdpByeByePacket(upnp->NOTIFY_SEND_socks[i], upnp, (struct sockaddr*)&(upnp->MulticastAddrV4), UPNP_MCASTv4_GROUP, "", "uuid:", upnp->UDN, 0);
			UPnPBuildSendSsdpByeByePacket(upnp->NOTIFY_SEND_socks[i], upnp, (struct sockaddr*)&(upnp->MulticastAddrV4), UPNP_MCASTv4_GROUP, "::urn:schemas-upnp-org:device:Sample:1", "urn:schemas-upnp-org:device:Sample:1", "", 0);
			UPnPBuildSendSsdpByeByePacket(upnp->NOTIFY_SEND_socks[i], upnp, (struct sockaddr*)&(upnp->MulticastAddrV4), UPNP_MCASTv4_GROUP, "::urn:schemas-upnp-org:service::1", "urn:schemas-upnp-org:service::1", "", 0);
			
		}
	}
	
	for (i=0; i<upnp->AddressListV6Length; ++i)
	{	
		if (ILibAsyncSocket_IsIPv6LinkLocal((struct sockaddr*)&(upnp->AddressListV6[i])))
		{
			t1 = (struct sockaddr*)&(upnp->MulticastAddrV6LL);
			t2 = UPNP_MCASTv6_LINK_GROUPB;
		}
		else
		{
			t1 = (struct sockaddr*)&(upnp->MulticastAddrV6SL);
			t2 = UPNP_MCASTv6_GROUPB;
		}
		
		for (i2=0; i2<2; i2++)
		{
			UPnPBuildSendSsdpByeByePacket(upnp->NOTIFY_SEND_socks6[i], upnp, t1, t2, "::upnp:rootdevice", "upnp:rootdevice", "", 0);
			UPnPBuildSendSsdpByeByePacket(upnp->NOTIFY_SEND_socks6[i], upnp, t1, t2, "", "uuid:", upnp->UDN, 0);
			UPnPBuildSendSsdpByeByePacket(upnp->NOTIFY_SEND_socks6[i], upnp, t1, t2, "::urn:schemas-upnp-org:device:Sample:1", "urn:schemas-upnp-org:device:Sample:1", "", 0);
			UPnPBuildSendSsdpByeByePacket(upnp->NOTIFY_SEND_socks6[i], upnp, t1, t2, "::urn:schemas-upnp-org:service::1", "urn:schemas-upnp-org:service::1", "", 0);
			
		}
	}
}

/*! \fn UPnPResponse_Error(const UPnPSessionToken UPnPToken, const int ErrorCode, const char* ErrorMsg)
\brief Responds to the client invocation with a SOAP Fault
\param UPnPToken UPnP token
\param ErrorCode Fault Code
\param ErrorMsg Error Detail
*/
void UPnPResponse_Error(const UPnPSessionToken UPnPToken, const int ErrorCode, const char* ErrorMsg)
{
	char* body;
	int bodylength;
	char* head;
	int headlength;
	int len = 395 + (int)strlen(ErrorMsg);
	
	if ((body = (char*)malloc(len)) == NULL) ILIBCRITICALEXIT(254);
	bodylength = snprintf(body, len, "<s:Envelope\r\n xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><s:Fault><faultcode>s:Client</faultcode><faultstring>UPnPError</faultstring><detail><UPnPError xmlns=\"urn:schemas-upnp-org:control-1-0\"><errorCode>%d</errorCode><errorDescription>%s</errorDescription></UPnPError></detail></s:Fault></s:Body></s:Envelope>",ErrorCode,ErrorMsg);
	if ((head = (char*)malloc(59)) == NULL) ILIBCRITICALEXIT(254);
	headlength = snprintf(head, 59, "HTTP/1.1 500 Internal\r\nContent-Length: %d\r\n\r\n",bodylength);
	ILibWebServer_Send_Raw((struct ILibWebServer_Session*)UPnPToken, head, headlength, 0, 0);
	ILibWebServer_Send_Raw((struct ILibWebServer_Session*)UPnPToken, body, bodylength, 0, 1);
}

void UPnPResponseGeneric(const UPnPMicroStackToken UPnPToken, const char* ServiceURI, const char* MethodName, const char* Params)
{
	int RVAL = 0;
	char* packet;
	int packetlength;
	struct ILibWebServer_Session *session = (struct ILibWebServer_Session*)UPnPToken;
	size_t len = 239 + strlen(ServiceURI) + strlen(Params) + (strlen(MethodName) * 2);
	
	if ((packet = (char*)malloc(len)) == NULL) ILIBCRITICALEXIT(254);
	packetlength = snprintf(packet, len, "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<s:Envelope s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body><u:%sResponse xmlns:u=\"%s\">%s</u:%sResponse></s:Body></s:Envelope>",MethodName,ServiceURI,Params,MethodName);
	LVL3DEBUG(printf("SendBody: %s\r\n", packet);)
	#if defined(WIN32) || defined(_WIN32_WCE)
	RVAL=ILibWebServer_StreamHeader_Raw(session, 200, "OK", "\r\nEXT:\r\nCONTENT-TYPE: text/xml; charset=\"utf-8\"\r\nSERVER: WINDOWS, UPnP/1.0, MicroStack/1.0.5329", 1);
	#elif defined(__SYMBIAN32__)
	RVAL=ILibWebServer_StreamHeader_Raw(session, 200, "OK", "\r\nEXT:\r\nCONTENT-TYPE: text/xml; charset=\"utf-8\"\r\nSERVER: SYMBIAN, UPnP/1.0, MicroStack/1.0.5329", 1);
	#else
	RVAL=ILibWebServer_StreamHeader_Raw(session, 200, "OK", "\r\nEXT:\r\nCONTENT-TYPE: text/xml; charset=\"utf-8\"\r\nSERVER: POSIX, UPnP/1.0, MicroStack/1.0.5329", 1);
	#endif
	if (RVAL!=ILibAsyncSocket_SEND_ON_CLOSED_SOCKET_ERROR && RVAL != ILibWebServer_SEND_RESULTED_IN_DISCONNECT)
	{
		RVAL=ILibWebServer_StreamBody(session, packet, packetlength, 0, 1);
	}
}

/*! \fn UPnPResponse_ImportedService_turn(const UPnPSessionToken UPnPToken)
\brief Response Method for ImportedService >> urn:schemas-upnp-org:service::1 >> turn
\param UPnPToken MicroStack token
*/
void UPnPResponse_ImportedService_turn(const UPnPSessionToken UPnPToken)
{
	UPnPResponseGeneric(UPnPToken,"urn:schemas-upnp-org:service::1","turn","");
}


void UPnPSendEventSink(
void *WebReaderToken,
int IsInterrupt,
struct packetheader *header,
char *buffer,
int *p_BeginPointer,
int EndPointer,
int done,
void *subscriber,
void *upnp,
int *PAUSE)	
{
	UNREFERENCED_PARAMETER( WebReaderToken );
	UNREFERENCED_PARAMETER( IsInterrupt );
	UNREFERENCED_PARAMETER( buffer );
	UNREFERENCED_PARAMETER( p_BeginPointer );
	UNREFERENCED_PARAMETER( EndPointer );
	UNREFERENCED_PARAMETER( PAUSE );
	
	if (done != 0 && ((struct SubscriberInfo*)subscriber)->Disposing == 0)
	{
		sem_wait(&(((struct UPnPDataObject*)upnp)->EventLock));
		--((struct SubscriberInfo*)subscriber)->RefCount;
		if (((struct SubscriberInfo*)subscriber)->RefCount == 0)
		{
			LVL3DEBUG(printf("\r\n\r\nSubscriber at [%s] %d.%d.%d.%d:%d was/did UNSUBSCRIBE while trying to send event\r\n\r\n", ((struct SubscriberInfo*)subscriber)->SID, (((struct SubscriberInfo*)subscriber)->Address&0xFF),((((struct SubscriberInfo*)subscriber)->Address>>8)&0xFF),((((struct SubscriberInfo*)subscriber)->Address>>16)&0xFF), ((((struct SubscriberInfo*)subscriber)->Address>>24)&0xFF), ((struct SubscriberInfo*)subscriber)->Port);)
			UPnPDestructSubscriberInfo(((struct SubscriberInfo*)subscriber));
		}
		else if (header == NULL)
		{
			LVL3DEBUG(printf("\r\n\r\nCould not deliver event for [%s] %d.%d.%d.%d:%d UNSUBSCRIBING\r\n\r\n", ((struct SubscriberInfo*)subscriber)->SID, (((struct SubscriberInfo*)subscriber)->Address&0xFF),((((struct SubscriberInfo*)subscriber)->Address>>8)&0xFF), ((((struct SubscriberInfo*)subscriber)->Address>>16)&0xFF), ((((struct SubscriberInfo*)subscriber)->Address>>24)&0xFF), ((struct SubscriberInfo*)subscriber)->Port);)
			// Could not send Event, so unsubscribe the subscriber
			((struct SubscriberInfo*)subscriber)->Disposing = 1;
			UPnPExpireSubscriberInfo(upnp, subscriber);
		}
		sem_post(&(((struct UPnPDataObject*)upnp)->EventLock));
	}
}

void UPnPSendEvent_Body(void *upnptoken, char *body, int bodylength, struct SubscriberInfo *info)
{
	struct UPnPDataObject* UPnPObject = (struct UPnPDataObject*)upnptoken;
	struct sockaddr_in dest;
	int packetLength;
	char *packet;
	int ipaddr;
	int len;
	
	memset(&dest, 0, sizeof(dest));
	dest.sin_addr.s_addr = info->Address;
	dest.sin_port = htons(info->Port);
	dest.sin_family = AF_INET;
	ipaddr = info->Address;
	
	len = info->PathLength + bodylength + 483;
	if ((packet = (char*)malloc(len)) == NULL) ILIBCRITICALEXIT(254);
	packetLength = snprintf(packet, len, "NOTIFY %s HTTP/1.1\r\nSERVER: %s, UPnP/1.0, MicroStack/1.0.5329\r\nHOST: %s:%d\r\nContent-Type: text/xml; charset=\"utf-8\"\r\nNT: upnp:event\r\nNTS: upnp:propchange\r\nSID: %s\r\nSEQ: %d\r\nContent-Length: %d\r\n\r\n<?xml version=\"1.0\" encoding=\"utf-8\"?><e:propertyset xmlns:e=\"urn:schemas-upnp-org:event-1-0\"><e:property><%s></e:property></e:propertyset>",info->Path,UPnPPLATFORM,inet_ntoa(dest.sin_addr),info->Port,info->SID,info->SEQ,bodylength+137,body);
	++info->SEQ;
	
	++info->RefCount;
	ILibWebClient_PipelineRequestEx(UPnPObject->EventClient, (struct sockaddr*)(&dest), packet, packetLength, 0, NULL, 0, 0, &UPnPSendEventSink, info, upnptoken);
}

void UPnPSendEvent(void *upnptoken, char* body, const int bodylength, const char* eventname)
{
	struct SubscriberInfo *info = NULL;
	struct UPnPDataObject* UPnPObject = (struct UPnPDataObject*)upnptoken;
	struct sockaddr_in dest;
	LVL3DEBUG(struct timeval tv;)
	
	if (UPnPObject == NULL)
	{
		free(body);
		return;
	}
	sem_wait(&(UPnPObject->EventLock));
	if (strncmp(eventname,"ImportedService",15)==0)
	{
		info = UPnPObject->HeadSubscriberPtr_ImportedService;
	}
	
	memset(&dest, 0, sizeof(dest));
	while(info != NULL)
	{
		if (!UPnPSubscriptionExpired(info))
		{
			UPnPSendEvent_Body(upnptoken, body, bodylength, info);
		}
		else
		{
			// Remove Subscriber
			LVL3DEBUG(gettimeofday(&tv, NULL);)
			LVL3DEBUG(printf("\r\n\r\nTIMESTAMP: %d\r\n", tv.tv_sec);)
			LVL3DEBUG(printf("Did not renew [%s] %d.%d.%d.%d:%d UNSUBSCRIBING <%d>\r\n\r\n", ((struct SubscriberInfo*)info)->SID, (((struct SubscriberInfo*)info)->Address&0xFF), ((((struct SubscriberInfo*)info)->Address>>8)&0xFF),((((struct SubscriberInfo*)info)->Address>>16)&0xFF), ((((struct SubscriberInfo*)info)->Address>>24)&0xFF), ((struct SubscriberInfo*)info)->Port, info);)
		}
		info = info->Next;
	}
	sem_post(&(UPnPObject->EventLock));
}
/*! \fn UPnPSetState_ImportedService_unTourComplet(UPnPMicroStackToken upnptoken, int val)
\brief Sets the state of unTourComplet << urn:schemas-upnp-org:service::1 << ImportedService \par
\b Note: Must be called at least once prior to start
\param upnptoken The MicroStack token
\param val The new value of the state variable
*/
void UPnPSetState_ImportedService_unTourComplet(UPnPMicroStackToken upnptoken, int val)
{
	struct UPnPDataObject *UPnPObject = (struct UPnPDataObject*)upnptoken;
	char* body;
	int bodylength;
	char* valstr;
	if (val != 0) valstr = "true"; else valstr = "false";
	UPnPObject->ImportedService_unTourComplet = valstr;
	bodylength = 36 + (int)strlen(valstr);
	if ((body = (char*)malloc(bodylength)) == NULL) ILIBCRITICALEXIT(254);
	bodylength = snprintf(body, bodylength, "%s>%s</%s", "unTourComplet", valstr, "unTourComplet");
	UPnPSendEvent(upnptoken, body, bodylength, "ImportedService");
	free(body);
}


void UPnPDestroyMicroStack(void *object)
{
	struct UPnPDataObject *upnp = (struct UPnPDataObject*)object;
	struct SubscriberInfo  *sinfo,*sinfo2;	UPnPSendByeBye(upnp);
	sem_destroy(&(upnp->EventLock));
	
	if (upnp->AddressListV4 != NULL) free(upnp->AddressListV4);
	if (upnp->AddressListV6 != NULL) free(upnp->AddressListV6);
	if (upnp->NOTIFY_SEND_socks != NULL) free(upnp->NOTIFY_SEND_socks);
	if (upnp->NOTIFY_RECEIVE_socks != NULL) free(upnp->NOTIFY_RECEIVE_socks);
	if (upnp->NOTIFY_SEND_socks6 != NULL) free(upnp->NOTIFY_SEND_socks6);
	if (upnp->NOTIFY_RECEIVE_socks6 != NULL) free(upnp->NOTIFY_RECEIVE_socks6);
	free(upnp->UUID);
	free(upnp->Serial);
	free(upnp->DeviceDescription);
	sinfo = upnp->HeadSubscriberPtr_ImportedService;
	while(sinfo!=NULL)
	{
		sinfo2 = sinfo->Next;
		UPnPDestructSubscriberInfo(sinfo);
		sinfo = sinfo2;
	}
	
}

int UPnPGetLocalPortNumber(UPnPSessionToken token)
{
	return(ILibWebServer_GetPortNumber(((struct ILibWebServer_Session*)token)->Parent));
}

void UPnPSessionReceiveSink(
struct ILibWebServer_Session *sender,
int InterruptFlag,
struct packetheader *header,
char *bodyBuffer,
int *beginPointer,
int endPointer,
int done)
{
	char *txt;
	if (header != NULL && sender->User3 == NULL && done == 0)
	{
		sender->User3 = (void*)~0;
		txt = ILibGetHeaderLine(header,"Expect",6);
		if (txt!=NULL)
		{
			if (strcasecmp(txt,"100-Continue")==0)
			{
				// Expect Continue
				ILibWebServer_Send_Raw(sender,"HTTP/1.1 100 Continue\r\n\r\n",25,ILibAsyncSocket_MemoryOwnership_STATIC,0);
			}
			else
			{
				// Don't understand
				ILibWebServer_Send_Raw(sender,"HTTP/1.1 417 Expectation Failed\r\n\r\n",35,ILibAsyncSocket_MemoryOwnership_STATIC,1);
				ILibWebServer_DisconnectSession(sender);
				return;
			}
		}
	}
	if (header != NULL && done !=0 && InterruptFlag == 0)
	{
		UPnPProcessHTTPPacket(sender, header, bodyBuffer, beginPointer == NULL?0:*beginPointer, endPointer);
		if (beginPointer!=NULL) {*beginPointer = endPointer;}
	}
}
void UPnPSessionSink(struct ILibWebServer_Session *SessionToken, void *user)
{
	SessionToken->OnReceive = &UPnPSessionReceiveSink;
	SessionToken->User = user;
}

void UPnPSetTag(const UPnPMicroStackToken token, void *UserToken)
{
	((struct UPnPDataObject*)token)->User = UserToken;
}

void *UPnPGetTag(const UPnPMicroStackToken token)
{
	return(((struct UPnPDataObject*)token)->User);
}

UPnPMicroStackToken UPnPGetMicroStackTokenFromSessionToken(const UPnPSessionToken token)
{
	return(((struct ILibWebServer_Session*)token)->User);
}

UPnPMicroStackToken UPnPCreateMicroStack(void *Chain, const char* FriendlyName, const char* UDN, const char* SerialNumber, const int NotifyCycleSeconds, const unsigned short PortNum)

{
	struct UPnPDataObject* RetVal;
	char* DDT;	struct timeval tv;
	size_t len;
	if ((RetVal = (struct UPnPDataObject*)malloc(sizeof(struct UPnPDataObject))) == NULL) ILIBCRITICALEXIT(254);
	
	gettimeofday(&tv,NULL);
	srand((int)tv.tv_sec);
	
	// Complete State Reset
	memset(RetVal, 0, sizeof(struct UPnPDataObject));
	
	RetVal->ForceExit = 0;
	RetVal->PreSelect = &UPnPMasterPreSelect;
	RetVal->PostSelect = NULL;
	RetVal->Destroy = &UPnPDestroyMicroStack;
	RetVal->InitialNotify = 0;
	if (UDN != NULL)
	{
		len = (int)strlen(UDN) + 6;
		if ((RetVal->UUID = (char*)malloc(len)) == NULL) ILIBCRITICALEXIT(254);
		snprintf(RetVal->UUID, len, "uuid:%s", UDN);
		RetVal->UDN = RetVal->UUID + 5;
	}
	if (SerialNumber != NULL)
	{
		len = strlen(SerialNumber) + 1;
		if (len > 20) len = 20;
		if ((RetVal->Serial = (char*)malloc(len)) == NULL) ILIBCRITICALEXIT(254);
		memcpy(RetVal->Serial, SerialNumber, len);
		RetVal->Serial[len - 1] = 0;
	}
	
	len = 10 + UPnPDeviceDescriptionTemplateLengthUX+ (int)strlen(FriendlyName)  + (((int)strlen(RetVal->Serial) + (int)strlen(RetVal->UUID)) * 1);
	if ((RetVal->DeviceDescription = (char*)malloc(len)) == NULL) ILIBCRITICALEXIT(254);
	
	RetVal->WebServerTimer = ILibCreateLifeTime(Chain);
	RetVal->HTTPServer = ILibWebServer_Create(Chain, UPNP_HTTP_MAXSOCKETS, PortNum, &UPnPSessionSink, RetVal);
	RetVal->WebSocketPortNumber = (int)ILibWebServer_GetPortNumber(RetVal->HTTPServer);
	
	
	ILibAddToChain(Chain, RetVal);
	UPnPInit(RetVal ,Chain, NotifyCycleSeconds, PortNum);
	
	RetVal->EventClient = ILibCreateWebClient(5, Chain);
	RetVal->UpdateFlag = 0;
	
	DDT = ILibDecompressString((unsigned char*)UPnPDeviceDescriptionTemplate, UPnPDeviceDescriptionTemplateLength, UPnPDeviceDescriptionTemplateLengthUX);
	RetVal->DeviceDescriptionLength = snprintf(RetVal->DeviceDescription, len, DDT, FriendlyName, RetVal->Serial, RetVal->UDN);
	
	free(DDT);
	
	sem_init(&(RetVal->EventLock), 0, 1);
	return(RetVal);
}





