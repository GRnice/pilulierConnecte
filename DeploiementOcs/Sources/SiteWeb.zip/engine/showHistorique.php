<?php
if (is_file("./historique"))
{ 
	$hist = file_get_contents("./historique");
	$histtab = explode(PHP_EOL,$hist);
	$cnt = count($histtab);

$indicedeco = 1;
for ($i = $cnt - 2; $i >= 0; $i--) {

$explod = explode(";",$histtab[$i]);
	print_r("<br><br><b> $explod[3] </b><br><br>");
	
	print_r("nom du traitement = $explod[0]<br>");
	print_r("date de d&eacute;but du traitement = $explod[3] <br>");
	print_r("dur&eacute;e du traitement = $explod[1] jour(s)<br>");
	$poso = str_replace("-", "h ,", $explod[2]);
	print_r("posologie = $poso h");
	$indicedeco++;



}
}

?>