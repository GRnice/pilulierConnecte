<?php
if (isset($_POST["nomTraitement"]) and (isset($_POST["dureeTraitement"])) and (isset($_POST["Definir_les_prises"])))
{

	$nomTraitement = htmlspecialchars(trim(urldecode($_POST["nomTraitement"])));

	$dateDebutTraitement = htmlspecialchars(trim(urldecode($_POST["dateDebut"])));


	$sendRappel = htmlspecialchars(trim(urldecode($_POST["sendMailRappel"])));
	$dureeTraitement = (string)htmlspecialchars(trim(urldecode($_POST["dureeTraitement"])));
	
	$posologie = (string) htmlspecialchars(trim(urldecode($_POST["Definir_les_prises"])));
	unset($_POST);

	touch("./newTraitement");
	$timeSinceEpoch = time();
	// nomTraitement;dureeTraitement;posologie;dateDebutTraitement
	// TraitementPaie;4;8-12-16;06/02/2017
	print_r("$nomTraitement;$dureeTraitement;$posologie;$dateDebutTraitement;$sendRappel");
	file_put_contents("./historique","$nomTraitement;$dureeTraitement;$posologie;$dateDebutTraitement;$sendRappel".PHP_EOL,FILE_APPEND);
	$dureeTraitement = (string) (intval($dureeTraitement - 1));
	file_put_contents("./traitement","$nomTraitement;$dureeTraitement;$posologie;$dateDebutTraitement;$sendRappel".PHP_EOL);
	if (is_file("./historique"))
	{
		touch("./historique");
	}

	
	header("Location: http://ocs-ws.890m.com/");
}

?>