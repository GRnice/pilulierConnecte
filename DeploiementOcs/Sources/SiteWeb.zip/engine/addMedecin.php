<?php
if (isset($_POST["NOM_MEDECIN"]) && isset($_POST["MAIL_MEDECIN"]))
{
	if (is_file("./medecin"))
	{
		unlink("./medecin");
	}

	touch("./medecin");
	

	$nomMedecin = (string) htmlspecialchars(trim(urldecode($_POST["NOM_MEDECIN"])));
	$mailMedecin = (string) htmlspecialchars(trim(urldecode($_POST["MAIL_MEDECIN"])));
	$message = $nomMedecin.";".$mailMedecin;
	file_put_contents("./medecin",$message);
	header("Location: http://ocs-ws.890m.com/");
}

?>