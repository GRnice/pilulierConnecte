<?php
session_name("TchatFR");
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
     <title>Mon tuteur</title>
	<FONT FACE="Verdana" COLOR="#000000">
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="../hello.css" />
	<link rel="stylesheet" type="text/css" href="./SYSTEME/include/stylebarrenavigation.css" />
</head>
<body>
<fieldset style="width:180px;">
<form method="post" enctype="application/x-www-form-urlencoded" action="addMedecin.php">
<table>
<tr><td><h4>Mon tuteur</h4></td></tr>
<tr><td><input type="text" name="NOM_MEDECIN" value="Nom du tuteur" /></td></tr>
<tr><td><input type="text" name="MAIL_MEDECIN" value="mail" /></td></tr>
<tr><td><input type="submit" name="SENDMEDECIN" value="Enregistrer" /></td></tr>
</table>
</form>
</fieldset>
</body>
</html>