<?php
if (is_file("./traitement"))
{
	$traitementCourant = file_get_contents("./traitement");
	$explod = explode(";",$traitementCourant);
	print_r("nom du traitement = $explod[0]<br>");
	print_r("date de d&eacute;but du traitement = $explod[3] <br>");
	print_r("dur&eacute;e du traitement = $explod[1] jour(s)<br>");
	$poso = str_replace("-", "h ,", $explod[2]);
	print_r("posologie = $poso h");
}

?>