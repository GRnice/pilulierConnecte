<?php
if (isset($_GET["GET_TRAITEMENT"]))
{
	$contenu = file_get_contents( "./traitement");
	print_r($contenu);
}
else if (isset($_GET["NW_TRAITEMENT"]))
{
	if (is_file("./newTraitement"))
	{
		unlink("./newTraitement");
		print_r("YES");
		return;
	}
	print_r("NO");
	return;
}

else if (isset($_GET["GET_MEDECIN"]))
{
	if (is_file("./medecin"))
	{
		$medecin = file_get_contents("./medecin");
		print_r($medecin);
		return;
	}
}
?>