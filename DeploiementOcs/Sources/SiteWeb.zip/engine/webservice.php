<?php
session_name("TchatFR");
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
     <title>Pilulier</title>
	<FONT FACE="Verdana" COLOR="#000000">
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />

</head>
<body>
<fieldset style="width:400px;">
<form method="post" enctype="application/x-www-form-urlencoded" action="AddTraitement.php">
<table>
<tr><td><h4>Enregistrement du traitement</h4></td></tr>
<tr><td><input type="text" name="nomTraitement" value="Nom du traitement" /></td></tr>
<tr><td><input type="text" name="dateDebut" value="06/02/2017" /></td></tr>
<tr><td><input type="text" name="dureeTraitement" value="Durée du traitement en jours" /></td></tr>
<tr><td><input type="text" name="Definir_les_prises" value="8-12-18" /></td></tr>
<tr><td> Rappeller chaque prise <input type="text" name="sendMailRappel" value="oui" /></td></tr>
<tr><td><input type="submit" name="SENDLOGMDPSESSIONSTART" value="Enregistrer" /></td></tr>
</table>
</form>
</fieldset>
</body>
</html>